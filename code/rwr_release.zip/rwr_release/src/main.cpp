#include <iostream>
#include <fstream>
#include <sstream>
#include <cstdio>
#include <vector>
#include <map>
#include <getopt.h>

#include "precompute.h"

using namespace std;

double teleport = 0.15;
double tolerance = 1e-4;
double storeTolerance = tolerance * 1e-3;

string path;
string dataset;
int level;
int n = -1, m = -1;
double accTime = 0;

mutex mtx;
int threadNum = 15;
const int maxThread = 32;

bool wsWriteFlag = false;
bool hubpvWriteFlag = false;
bool pvWriteFlag = false;

/*test related*/
int portno = 55;
char hostName[] = "...";
int repTimes = 1;
string queryFile = "query.txt";

vector<int> getQuery(){
   ifstream ifs( (path + queryFile).c_str() );
   string line;
   std::vector<int> ret;
   while(getline(ifs, line)){
        istringstream iss(line);
        int node;
        iss >> node;
        //if the node is indexed from 1
        node--;
        ret.push_back(node);
   }
   ifs.close();
   return ret;
}

void _precom(int machineId, int machineNum){
    // readConfig();
    cout << "Level : " << level << endl;
    cout << "Path : " << path << endl;
    cout << "Dataset: " << dataset << endl;
    precom(threadNum, machineNum, machineId);
    double totalSeconds = getSeconds();
    pvPrecom(threadNum, machineNum, machineId);
    totalSeconds += getSeconds();
    cout << "Total Time used: " << totalSeconds * threadNum / 3600 << " h" << endl;
}

void powerIteration(){
    vector<int> queries = getQuery();
    // vector<int> queries;
    // queries.push_back(0);//1
    // queries.push_back(99);//100
    // queries.push_back(999);//1000
    hubRWR *rwr = new hubRWR();
    loadGraph(rwr);
    rwr->setTeleport(teleport);
    rwr->setTolerance(tolerance);
    for(auto & id : queries){
        setStartTime();
        double *res = rwr->iteration(id);
        setEndTime();
        double seconds = getSeconds();
        // cout << "Query: "<<id << " Time:" << seconds << "s Result:";
        // cout << res[id] << endl;
        for(int i=0;i<3;i++)
            cout << res[i] << " ";
        cout << endl;
        // break;
    }
}

double getSum(double *a, int len){
    double res = 0;
    for(int i=0;i<len;i++)
        res += a[i];
    return res;
}

void stats(double *pow_res, double *hhgpa_res, int len, double &maxDiff, double &avgDiff,\
    double &precision, int k, double &rag){
    vector<pair<double,int> >powTop;
    vector<pair<double,int> >hhgpaTop;
    for(int i=0;i<len;i++){
        maxDiff = max(maxDiff, fabs(pow_res[i] - hhgpa_res[i]));
        avgDiff += fabs(pow_res[i] - hhgpa_res[i]);

        powTop.push_back(make_pair(pow_res[i], i));
        hhgpaTop.push_back(make_pair(hhgpa_res[i], i));
    }
    sort(powTop.begin(), powTop.end());
    reverse(powTop.begin(), powTop.end());

    sort(hhgpaTop.begin(), hhgpaTop.end());
    reverse(hhgpaTop.begin(), hhgpaTop.end());
    if(k > len)
        k = len;
    map<int,int>powMap;
    double div = 0;
    for(int i = 0; i < k; i++){
        powMap[ powTop[i].second ] = 1;
        div += powTop[i].first;
    }
    for(int i = 0; i < k; i++){
        int j = hhgpaTop[i].second;
        if(powMap.count(j))
            precision += 1;
        rag += pow_res[j];
    }
    precision /= k;
    // cout << div << " " << rag << endl;
    rag /= div;
}

void getDiff(ifstream& ifs, double* pow_res, int len, double& maxDiff, double& avgDiff, double& tim,\
    double &precision, int k, double &rag){
    //TODO
    string line;
    getline(ifs, line);
    istringstream iss(line);
    char c;
    int id;
    double val;
    int msTime;
    string str;
    int cnt = 0;
    iss >> msTime >> str;
    tim += msTime * 0.0001;
    // cout << msTime << endl;
    
    double div = 0;
    map<int,int>powMap;
    vector<pair<double,int> >powTop;
    for(int i=0;i<len;i++){
        powTop.push_back(make_pair(pow_res[i], i));
    }
    sort(powTop.begin(), powTop.end());
    reverse(powTop.begin(), powTop.end());
    for(int i = 0; i < k;i++){
        powMap[ powTop[i].second ] = 1;
        div += powTop[i].first;
    }

    while(iss >> id >> c >> val){
        // cout << id << " " << val << endl;
        id--;
        maxDiff = max(maxDiff, fabs(pow_res[id] - val) );
        avgDiff += fabs(pow_res[id] - val);
        // if(fabs(pow_res[id] - val) > 0.3)
        //     cout << id <<" :" << pow_res[id] << " ? " << val << endl;
        if(cnt < k){
            if(powMap.count(id))
                precision += 1;
            rag += pow_res[id];
        }
        cnt++;
    }
    avgDiff /= cnt;
    precision /= k;
    rag /= div;
    // cout << maxDiff << " " << avgDiff << " len:" << cnt << endl;
}

// void compare(char* exactPath){
void compare(){
    // ifstream ifs( exactPath );

    vector<int> queries = getQuery();
    // queries.resize(100);
    //power iteration
    hubRWR *powIter = new hubRWR();
    loadGraph(powIter);
    powIter->setTeleport(teleport);
    powIter->setTolerance(tolerance);
    int len = powIter->getUserNum();

    // H-HGPA
    hubPPVCstruct *ppvC = new hubPPVCstruct();
    ppvC -> setMachineInfo(0, 1);
    loadPrec(ppvC);

    cerr << "Comparing..." << endl;
    int acc = 0;
    double maxAccDiff = 0, accdiff = 0, suma = 0, sumb = 0, accTime = 0;
    double accPrecision = 0, accRag = 0;
    double powTim = 0;
    for(auto & id : queries){
        setStartTime();
        double *pow_res = powIter->iteration(id);
        setEndTime();
        powTim += getSeconds();
        double maxDiff = 0;
        double avgDiff = 0;
        double precision = 0;
        int k = 50;
        double rag = 0;

        //H-HGPA
        ppvC -> cleanPPV();
        setStartTime();
        double *hhgpa_res = ppvC -> getPPV(id);
        setEndTime();
        accTime += getSeconds();
        stats(pow_res, hhgpa_res, len, maxDiff, avgDiff, precision, k, rag);
        avgDiff /= len;

        //FastPPV
        // getDiff(ifs, pow_res, len, maxDiff, avgDiff, accTime, precision, k, rag);
        // cout << precision << " " << rag << endl;

        maxAccDiff += maxDiff;
        accdiff += avgDiff;
        accPrecision += precision;
        accRag += rag;
        // suma += getSum(pow_res, len);
        // sumb += getSum(hhgpa_res, len);
        if(acc++ % 10 == 0)
            cerr << ".";
    }
    suma /= queries.size();
    sumb /= queries.size();
    accdiff /= queries.size();
    maxAccDiff /= queries.size();
    accTime /= queries.size();
    accPrecision /= queries.size();
    accRag /= queries.size();
    powTim /= queries.size();
    cout << endl << "Max Difference: " << maxAccDiff << endl;
    cout << "Average Difference: " << accdiff << endl;
    // cout << "Power Iteration Sum: " << suma << endl;
    // cout << "H-HGPA Sum: " << sumb << endl;
    cout << "Average Precision: " << accPrecision << endl;
    cout << "Average RAG: " << accRag << endl;
    cout << "HHGPA Time: " << accTime << "s" << endl;
    cout << "Power Iteration Time: " << powTim << "s" << endl;

    // ifs.close();
}

void construction(unsigned machineId = 0, unsigned machineNum = 1){
    // readConfig();
    hubPPVCstruct *ppvC = new hubPPVCstruct();
    ppvC -> setMachineInfo(machineId, machineNum);
    loadPrec(ppvC);
    vector<int> queries = getQuery();

    double inf = 1e55;
    double totTime = 0;
    double maxRoundTime = 0;
    double minRoundTime = inf;
    double maxSingleTime = 0;
    double minSingleTime = inf;

    unsigned entryNum = 0;
    for(int rep = 0; rep < repTimes; rep++){
        double roundTime = 0;
        for(auto& id : queries){
            ppvC -> cleanPPV();
            setStartTime();
            double * t = ppvC -> getPPV(id);
            /* for(int i=0;i<3;i++) */
                /* cout << t[i] << " "; */
            /* cout << endl; */
            setEndTime();
            entryNum += ppvC -> countNonEmptyEntry();
            /* cout << entryNum << endl; */
            double seconds = getSeconds();
            totTime += seconds;
            roundTime += seconds;
            maxSingleTime = max(maxSingleTime, seconds);
            minSingleTime = min(minSingleTime, seconds);
       }
       maxRoundTime = max(maxRoundTime, roundTime);
       minRoundTime = min(minRoundTime, roundTime);
   }
   cout << "Average Time: " << totTime / repTimes / queries.size() * 1000 << " ms" << endl;
   cout << "Average Communication Cost: " << entryNum * 4 / 1024 / queries.size() << " KB" << endl;
   // cout << "Min/Max single runtime: " << minSingleTime * 1000 << " " << maxSingleTime * 1000 << " ms" << endl;
   // cout << "Min/Max round runtime: " << minRoundTime * 1000 << " " << maxRoundTime * 1000 << " ms" << endl;
}

int main(int argc, char *argv[]){
    //net comm test
    /* { */
    /*     if(argc == 2){ */
    /*         /1* server(atoi(argv[1])); *1/ */
    /*     } */
    /*     else if(argc == 3){ */
    /*         /1* client(atoi(argv[1]), argv[2]); *1/ */
    /*     } */
    /*     else{ */
    /*         fprintf(stderr,"ERROR, no port provided\n"); */
    /*         exit(1); */
    /*     } */
    /*     return 0; */
    /* } */
    int oc;
    int machineId = 0;
    int machineNum = 1;
    while((oc = getopt(argc, argv, "Iprq:t:i:m:e:l:P:d:hcg:")) != -1){
        switch(oc){
            case 'g':
                storeTolerance = atof(optarg);
                break;
            case 'c':
                // compare(optarg);
                compare();
                break;
            case 'I':
                powerIteration();
                break;
            case 'p':
                _precom(machineId, machineNum);
                break;
            case 'r':
                construction(machineId, machineNum);
                break;
            case 'q':
                queryFile = optarg;
                break;
            case 't':
                threadNum = atoi(optarg);
                break;
            case 'i':
                machineId = atoi(optarg);
                break;
            case 'm':
                machineNum = atoi(optarg);
                break;
            case 'e':
                tolerance = atof(optarg);
                cout << "Tolerance is set as " << tolerance << endl;
                break;
            case 'l':
                level = atoi(optarg);
                break;
            case 'P':
                path = optarg;
                break;
            case 'd':
                dataset = optarg;
                break;
            case 'h':
                break;
            case '?':
                printf("arguments error!\n");
                break;
        }
    }
    return 0;
}
