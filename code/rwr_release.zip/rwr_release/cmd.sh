#precomputation
./rwr -P /home/guotao/rwr_release/data/graph/ -d email-EuAll -l 0 -p
#query
#./rwr -P /home/guotao/rwr_release/data/graph/ -d email-EuAll -q query.txt -c

