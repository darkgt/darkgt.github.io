Simply follow the bash script cmd.sh to do pre-compute and run  the query. A dataset email-EuAll is also attached.

Some explanation about the arguments:
-e set tolerance epsilon, default 1e-4
-g set storage tolerance of pre-computation results, default 1e-7
                Very small results will be ignored less than this value
-q path of query file 
-P path of dataset
-d name of dataset
-l set the level of hierarchy

-I run power method
-c compare with baseline
-p run pre-computation
-r run queries

-t set number of threads on each machine

Now for your urging needs I did not put the network function into the codes. However, suppose you have x machines as slavers you can use the �i and �t arguments:
On machine 0, use �i 0  �t x
On machine 1, use �i 1  �t x
�

For the data format, please check the sample dataset. Graph nodes are indexed from 1.
The xxx.hub file is the hubnodes of graph, where each line is: nodeid \t level.
The level indicates the level of the hub node, where 1 is the highest.

I use metis-5.0rc3 to do the graph partitioning. And I wrote a simple tool to select hub nodes based on metis results (which are hub edges). The tool is also attached.
Since this part is free to our problem, you can simply do your own partitioning and keep the result in the xxx.hub file, which will also work.
