/* Author: Guo Tao
 * Email: tguo001@e.ntu.edu.sg 
 */
#include <time.h>
#include <iostream>
#include <unistd.h>

#include "../lib/sweepcircle.h"

#define FRESULT

bool isexact = false;

void query(char * queryfile){
    EnclosingCircle ec;
    string line;
    string resFile = string(queryfile) + (isexact ? ".exares":".appres");
    ifstream ifs(queryfile);
    ofstream ofs(resFile.c_str());
    int caseid = 0;
    while(ifs >> line){
        Query Q(line, 0, 0);
        cerr << "Case: " << ++caseid << endl;
        ec.solve(&Q);
        ec.show(ofs);
    }
    ifs.close();
    ofs.close();
}

void buildInvertedFile(){
    EnclosingCircle ec;
    ec.buildInvertedFile();
}

void usage(){
    cerr << "Parameters Explanation:" << endl;
    cerr << "-d [dataset]:\t specify dataset e.g. -d data/NewYork/" << endl;
    cerr << "-b:\t\t build inverted file, used with -d" << endl;
    cerr << "-q [querypath]:\t run queries, used with -d" << endl;
    cerr << "-e [0/1]:\t 0-appr queries 1-exact queries, used with -q" << endl;
    cerr << "-h:\t\t help" << endl;
    //cerr << "-g [seednum]:\t generate queries, 2~10 keywords from randomly choosed [seednum] objects, 50 queries in one file, used with -d"  << endl;
}

int main(int argc, char ** argv)
{
    string queryfile;
    int c;
    while ( (c = getopt(argc, argv, "d:bq:e:h")) != -1 ){
        switch (c)
        {
            case 'd':
                dataset = optarg;
                invertedFileFolder = dataset + "index/";
                locFile = dataset + "/loc";
                docFile = dataset + "/doc";
                break;
            case 'b':
                cerr << "Build inverted file" << endl;
                buildInvertedFile();
                break;
            case 'q':
                if(isexact)
                    cerr << "Running exact queries" << endl;
                else
                    cerr << "Running appr queries" << endl;
                query(optarg);
                break;
            case 'e':
                isexact = atoi(optarg);
                break;
            /*
            case 'g':
                cerr << "Generate queries" << endl;
                seednum = atoi(optarg);
                genquery(seednum);
                break;
            */
            case 'h':
                usage();
                break;
            case '?':
                cerr << "Unknown option character " << (char)optopt <<endl;
                usage();
                return 1;
            default:
                usage();
                abort();
        }
    }
    return 0;
}
