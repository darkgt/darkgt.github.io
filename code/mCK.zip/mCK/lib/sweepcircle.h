#ifndef _SWEEPCIRCLE_
#define _SWEEPCIRCLE_

#include <iostream>
#include <sstream>
#include <fstream>
#include <algorithm>
#include <queue>
#include <map>
#include <set>
#include <vector>
#include <cmath>
#include <cstring>
#include <sys/stat.h>

#include "../lib/Tool.h"

using namespace std;

extern bool isexact;

//string dataset = "data/dataGN/";
string dataset = "";

string invertedFileFolder = dataset + "index/";
string locFile = dataset + "/loc";
string docFile = dataset + "/doc";

//#define ONLYCHOICE
//#define DEBUG
//#define SHOWAPPRES
//#define TIMEOUT

class EnclosingCircle
{
protected:
    Query *Q;
    vector<int> keywords;
    unsigned int keywordsnum;
    vector<Object>Obj;
    double lambda;
    double pi;

    Grid grid;
    unsigned int keywordsBM;//bitmask
    unsigned int maxKeywordFreqIndex;

    double bestcost;//result
    set<int>result;

    map<int, vector<int> >invertedFile; //keywords -> id
    map<int, pair<double, double> >invertedLoc; //id -> location

    //Test Function
    struct rusage startTime;
    struct rusage endTime;
    double userTime;
    double sysTime;

    double timeout;
    vector<int> keywordsFreq;

    double ansLowerbound;

    //nomalize the angle to 0~2*pi
    double normalizeAngle(double angle){
        while(angle < 0)
            angle += 2*pi;
        while(angle > pi*2)
            angle -= 2*pi;
        return angle;
    }
    double Objdist(const Object &a,const Object &b){
        return sqrt( (a.x-b.x)*(a.x-b.x) + (a.y-b.y)*(a.y-b.y) );
    }

    double Querydist(const Object &a){
        return sqrt( (a.x-Q->x) * (a.x-Q->x) + (a.y-Q->y) * (a.y-Q->y) );
    }

    void getangle(const Object &a,const Object &b,double &inangle,double &outangle,double diameter){
        double dist = Objdist(a, b);
        double baseangle;
        double x = b.x - a.x;
        double y = b.y - a.y;
        baseangle = atan2(y, x);
        //cerr<<a.x<<","<<a.y<<endl;
        //cerr<<b.x<<","<<b.y<<endl;
        //cerr<<baseangle<<endl;
        double alpha = acos( dist/diameter );
        inangle = normalizeAngle(baseangle - alpha);
        outangle = normalizeAngle(baseangle + alpha);
    }
    virtual inline bool update(double cost){
        bestcost = cost + 0.01;
        return true;
    }
    virtual inline bool update(double cost, const set<int>&group){
        if(cost < bestcost){
            bestcost = cost;
            result = group;
            return true;
        }
        return false;
    }
    virtual inline double bestdist(){
        return bestcost;
    }

public:
    unsigned int Objnum;

    inline bool istimeout(){
        getTime(&startTime, &endTime, &userTime, &sysTime);
        return userTime > timeout;
    }

    void buildInvertedFile()
    {
        //clear folder
        char cmd[1000];
        strcpy (cmd, "rm -r ");
        strcat (cmd, invertedFileFolder.c_str());
        system(cmd);
        //mkdir
        strcpy (cmd, "mkdir ");
        strcat (cmd, invertedFileFolder.c_str());
        system(cmd);

        cerr << "[DEBUG]Building inverted files" << endl;
        ifstream locFS(locFile.c_str());
        ifstream docFS(docFile.c_str());

        if(!locFS.is_open()){
            cerr << "Location File [" << locFile << "] open failed." << endl;
            return;
        }
        if(!docFS.is_open()){
            cerr << "Document File [" << docFile << "] open failed." << endl;
            return;
        }

        string lLine;
        string dLine;
        int lineNum = 0;
        while(docFS >> dLine){
            locFS >> lLine;
            istringstream lIss(lLine);
            istringstream dIss(dLine);
            int oid;
            char c;
            double x, y;
            int wid;

            lIss >> oid >> c >> x >> c >> y;
            dIss >> oid;
            while(dIss >> c >> wid){
                //trans int to string
                stringstream ss;
                ss << wid;
                string swid = ss.str();
                ofstream oFS((invertedFileFolder + swid).c_str(), ios::out | ios::app);
                if(!oFS.is_open()){
                    cerr << "Inverted File [" << invertedFileFolder + swid << "] build failed" << endl;
                    return;
                }
                oFS << lineNum << "\t" << x << "\t" << y << "\t" << endl; 
                oFS.close();
            }
            lineNum++;
        }

        locFS.close();
        docFS.close();
        cerr << "[DEBUG]Inverted files done"<< endl;
    }

    void show(ostream &out = std::cerr)
    {
        double dist = 0;
        int mask = 0;
        for(set<int>::iterator i =result.begin();i!=result.end();i++){
            mask |= Obj[*i].mask;
            for(set<int>::iterator j =result.begin();j!=result.end();j++){
                double len = Objdist(Obj[*i],Obj[*j]);
                if(len>dist)dist = len;
                len = Querydist(Obj[*i]);
            }
        }
#ifdef DEBUG
        cerr << "[DEBUG]Runtime:\t" << userTime << "s" << endl;
        cerr << "[DEBUG]Review:\n" << dist << " mask: " << mask << endl;
#endif
        out<< bestdist() <<" : ";
        for(set<int>::iterator i=result.begin();i!=result.end();i++)
            out<<Obj[*i].oid<<" ";
        
        out << "\t" << userTime;
        out<<endl;
    }

    virtual void solve(Query *Q)
    {
        timeout = 5 * 60;
        getCurTime(&startTime);

        lambda  = sqrt(3.0)/2;
        pi      = acos(-1.0);
        this->Q = Q;

        /*
         * call R-Tree to get an approximation result
         *
         IBRTree *rt = new IBRTree();
         rt->ReadTree();
         Problem2Appr2 pb2a2(Q, nodeNum);
         rt->GetTree()->queryStrategy(pb2a2);
         double cost = pb2a2.getCost();
         update(cost * 2);
         delete rt;
         */

        /*
           vector<int> *iniGroup = pb2a2.getGroup();
           vector<int>::iterator vi = iniGroup->begin();
           for(; vi != iniGroup->end(); ++vi)
           {
        //result.insert(*vi);
        }
        */
        istringstream iss(Q->text);
        int wid;
        char c;
        keywords.clear();
        while(iss >> wid)
        {
            keywords.push_back(wid);
            iss >> c;
        }
        keywordsnum = keywords.size();
        keywordsBM = (1 << keywords.size()) - 1;

        Obj.clear();
        grid.clear();
        result.clear();

#ifdef DEBUG
        //cerr<<"[DEBUG]"<<bestdist()/2<<endl;
#endif

        /*
         * get objects containing query keywords
         * should be replaced by inverted list
         *
         SearchIBRTree ss(Q, nodeNum, -1, bestdist());
         IBRTree irtree;
         irtree.ReadTree();
         irtree.GetTree()->queryStrategy(ss);

         vector<Object>::iterator iter;
         for(iter = ss.res.begin(); iter != ss.res.end(); iter++){
        //cerr<<iter->second.oid<<" "<<iter->second.mask<<" "<<iter->second.x<<","<<iter->second.y<<endl;
        Obj.push_back(*iter);
        grid.insert(*iter);
        }
        */
        map<int, int> oid2index;
        for(unsigned i = 0; i < keywords.size(); i++){
            stringstream ss;
            ss << keywords[i];
            string swid = ss.str();
            ifstream iFS((invertedFileFolder + swid).c_str());
            string line;
            while(getline(iFS, line)){
                istringstream iss(line);
                int oid;
                double x, y;
                iss >> oid >> x >> y;
                if(oid2index.count(oid)){
                    Obj[ oid2index[oid] ].mask |= 1 << i;
                }
                else{
                    Object cur;
                    cur.x = x;
                    cur.y = y;
                    cur.oid = oid;
                    cur.mask = 1 << i;
                    cur.id = oid2index[oid] = Obj.size();
                    Obj.push_back(cur);
                }
            }
            iFS.close();
        }

        for(unsigned i = 0; i < Obj.size(); i++){
            grid.insert(Obj[i]);
        }

        Objnum = Obj.size();
#ifdef DEBUG
        cerr<<"[DEBUG]Object num: "<<Objnum<<endl;
#endif

        grid.init();
#ifdef DEBUG
        cerr<<"[DEBUG]Processing" << endl;
#endif
        Process();

        getCurTime(&endTime);
        getTime(&startTime, &endTime, &userTime, &sysTime);
    }

    EnclosingCircle(){}

    ~EnclosingCircle()
    {
    }

    virtual void search(const vector<int>&curset, set<int>selected, unsigned int mask, double pairdist, int inc){
#ifdef TIMEOUT
        if(istimeout()) return;
#endif
        if(mask == keywordsBM){
            if(pairdist < bestdist()){
                update(pairdist, selected);
            }
            return ;
        }
        if(pairdist > bestdist())
            return;

        vector<int>nextset;
        vector<double>nextlen;
        int nextmask = 0;
#ifdef ONLYCHOICE
        vector<int>invertedBitmask(keywordsnum, -1);
#endif

        for(vector<int>::const_iterator i = curset.begin(); i!= curset.end(); i++){
            if( (Obj[*i].mask & (keywordsBM^mask)) == 0 )
                continue;
            if( Obj[*i].oid < inc )
                continue;
            double len = pairdist;
            for(set<int>::iterator j=selected.begin();j!=selected.end();j++){
                double dist = Objdist(Obj[*i], Obj[*j]);
                if(dist > len){
                    len = dist;
                }
            }
            if(len > bestdist())
                continue;
#ifdef ONLYCHOICE
            for(unsigned j = 0; j < keywordsnum; j++){
                if(Obj[*i].mask & (1 << j)){
                    if(invertedBitmask[j] == -1)
                        invertedBitmask[j] = nextset.size();
                    else if(invertedBitmask[j] >= 0)
                        invertedBitmask[j] = -2;
                }
            }
#endif
            nextlen.push_back(len);
            nextset.push_back(*i);
            nextmask |= Obj[*i].mask;
        }

        if( (nextmask|mask) != keywordsBM)
            return;

#ifdef ONLYCHOICE
        for(unsigned j = 0; j < keywordsnum; j++){
            if( ((keywordsBM ^ mask) & (1 << j)) && invertedBitmask[j] >= 0 ){
                int add = nextset[invertedBitmask[j]];
                mask |= Obj[add].mask;
                pairdist = max(pairdist, nextlen[invertedBitmask[j]]);
                selected.insert(add);
                break;
            }
        }
#endif

        for(unsigned i = 0; i < nextset.size(); i++){
            int id = nextset[i];
            selected.insert(id);
            search(nextset, selected, mask | Obj[id].mask, max(nextlen[i], pairdist), Obj[id].oid);
            selected.erase(id);
        }
    }

    void checkcircle(const set<int>& candidates, const vector<int>& selectedVec){
#ifdef TIMEOUT
        if(istimeout()) return;
#endif
        int basemask = 0;
        set<int> selectedSet;
        double selectedPairDist = 0.0;
        for(unsigned i = 0; i < selectedVec.size(); i++){
            basemask |= Obj[ selectedVec[i] ].mask;
            selectedSet.insert(selectedVec[i]);
            for(unsigned j = i+1; j < selectedVec.size(); j++){
                selectedPairDist = max(selectedPairDist, Objdist(Obj[selectedVec[i]], Obj[selectedVec[j]]));
            }
        }

        vector<int>candiadatesVec;
        for(set<int>::const_iterator it = candidates.begin(); it != candidates.end(); it++){
            candiadatesVec.push_back(*it);
            double dist2all = 0;
            for(unsigned i = 0; i < candiadatesVec.size(); i++){
                dist2all = max(dist2all, Objdist(Obj[candiadatesVec[i]], Obj[*it]));
            }
            for(set<int>::const_iterator i = candidates.begin(); i != candidates.end(); i++){
                dist2all = max(dist2all, Objdist(Obj[*i], Obj[*it]));
            }
            //free add
            if(dist2all < ansLowerbound && (Obj[*it].mask & (keywordsBM ^ basemask)) ){
                basemask |= Obj[*it].mask;
                selectedSet.insert(*it);
                selectedPairDist = max(selectedPairDist, dist2all);
            }
        }
        search(candiadatesVec, selectedSet, basemask, selectedPairDist, -1);
    }

    void updateApprRes(const set<int>& candidates, const vector<int>& selectedVec){
        //return;
        double pairdist = 0;
        set<int> selected;
        unsigned mask = 0;
        for(unsigned i = 0; i < selectedVec.size(); i++){
            selected.insert(selectedVec[i]);
            mask |= Obj[selectedVec[i]].mask;
            for(unsigned j = i + 1; j < selectedVec.size(); j++){
                pairdist = max(pairdist, Objdist(Obj[selectedVec[i]], Obj[selectedVec[j]]));
            }
        }
        for(set<int>::const_iterator it = candidates.begin(); mask != keywordsBM && it != candidates.end(); it++){
            if( Obj[*it].mask & (keywordsBM ^ mask) ){
                for(set<int>::iterator i = selected.begin(); i != selected.end(); i++){
                    pairdist = max(pairdist, Objdist(Obj[*i], Obj[*it]));
                }
                mask |= Obj[*it].mask;
                selected.insert(*it);
            }
        }
        update(pairdist, selected);
    }

    bool sweep(int pivot, double diameter, bool ischeck, bool isapprupdate = false){
        //vector<int> near = grid.query(Obj[pivot].x, Obj[pivot].y, diameter, keywordsBM ^ Obj[pivot].mask, Q->x, Q->y, furthest);
        vector<int> near = grid.query(Obj[pivot].x, Obj[pivot].y, diameter, keywordsBM ^ Obj[pivot].mask);
        unsigned int mask = Obj[pivot].mask;
        int circle = 0;
        bool ret = false;
        unsigned int curmask = 0;

        for(unsigned j=0;j<near.size();j++){
            mask |= Obj[near[j]].mask;
        }
        if(mask != keywordsBM)
            return false;

        mask = keywordsBM ^ Obj[pivot].mask; //target mask
        vector<int>countBitmask(keywordsnum,0);

        priority_queue<pair<double,int>,vector<pair<double,int> >, greater<pair<double,int> > >inqueue;
        priority_queue<pair<double,int>,vector<pair<double,int> >, greater<pair<double,int> > >outqueue;
        map<int,double>outangleMap;//index -> outangle
        set<int>curset;//current objects set
        curset.insert(pivot);
        double curangle = 0;
        for(unsigned j=0;j<near.size();j++){
            double inangle,outangle;
            getangle( Obj[pivot], Obj[near[j]],inangle,outangle,diameter);
            if(outangle < inangle){
                outangleMap[near[j]] = outangle;
                outqueue.push(pair<double,int>(outangle, near[j]) );
                curset.insert(near[j]);
                for(unsigned k=0;k<keywordsnum;k++)
                    if( (mask & (1<<k)) && (Obj[near[j]].mask & (1<<k) )){
                        countBitmask[k]++;
                        curmask |= 1<<k;
                    }
            }
            else{
                outangleMap[near[j]] = outangle;
                inqueue.push(pair<double,int>(inangle, near[j]));
            }
        }
        if(curmask == mask){
            ret = true;
            if(ischeck)
                circle ++;
            else{
                if(isapprupdate){
                    vector<int>selected;
                    selected.push_back(pivot);
                    updateApprRes(curset, selected);
                }
                return ret;
            }
            if(ischeck){
                vector<int>selected;
                selected.push_back(pivot);
                checkcircle(curset, selected);
            }
        }
        while(inqueue.size() > 0){
            double add = inqueue.top().first - curangle;
            if(outqueue.size() == 0 || (outqueue.top().first- curangle) > add){
                int in = inqueue.top().second;
                curset.insert(in);
                outqueue.push(pair<double, int>(outangleMap[in], in));
                for(unsigned k=0;k<keywordsnum;k++)
                    if( (mask & (1<<k)) && (Obj[in].mask & (1<<k) )){
                        countBitmask[k]++;
                        curmask |= 1<<k;
                    }
                curangle += add;
                inqueue.pop();
                if(curmask == mask){
                    ret = true;
                    if(ischeck)
                        circle ++;
                    else{
                        if(isapprupdate){
                            vector<int>selected;
                            selected.push_back(pivot);
                            updateApprRes(curset, selected);
                        }
                        break;
                    }
                    if(ischeck){
                        vector<int>selected;
                        selected.push_back(pivot);
                        selected.push_back(in);
                        checkcircle(curset, selected);
                    }
                }
            }
            else{
                int out = outqueue.top().second;
                curset.erase(out);
                for(unsigned k=0;k<keywordsnum;k++)
                    if( (mask & (1<<k)) && (Obj[out].mask & (1<<k) )){
                        countBitmask[k]--;
                        if(countBitmask[k] == 0)
                            curmask ^= 1<<k;
                    }
                curangle = outqueue.top().first;
                outqueue.pop();
            }
        }
        //if(ischeck)
        //	cerr << "loc: "<<circle<<endl;
        return ret;
    }

    double combinationCheck(int pivot, const vector<Object>& lowFreqObj){
        double ret = -1;
        for(unsigned i = 0;i < lowFreqObj.size(); i++){
            double pairDist = Objdist(Obj[pivot], lowFreqObj[i]);
            if(ret < 0 || pairDist < ret)
                ret = pairDist;
        }
        return ret;
        /*
           double qdist = Querydist(Obj[pivot]);
           double diameter = (bestdist() - qdist);
           vector<int> near;

           int xorMask = Obj[pivot].mask;

           for(unsigned i = 0;i < lowFreqObj.size(); i++){
           double furthest = max(qdist, Querydist(lowFreqObj[i]));
           double pairDist = Objdist(Obj[pivot], lowFreqObj[i]);

           if(furthest + pairDist > bestdist()){
           continue;
           }

           if(near.size() == 0){
           near = grid.query(Obj[pivot].x, Obj[pivot].y, diameter, keywordsBM ^ Obj[pivot].mask);
           }

           for(unsigned j = 0; j < near.size(); j++){
           int id = near[j];
        //double pairDist = Objdist(Obj[id], Obj[pivot]);
        double pairdist = max(Objdist(Obj[id], Obj[pivot]), Objdist(Obj[id], lowFreqObj[i]));

        if(max(furthest, Querydist(Obj[id])) + max(pairDist, pairdist) > bestdist()){
        continue;
        }
        xorMask |= Obj[id].mask | lowFreqObj[i].mask;
        }
        }
        if(keywordsBM == xorMask){
        return true;
        }
        else{
        //remove from data set
        grid.del(Obj[pivot]);
        return false;
        }
        */
    }

    void Process(){
        //try to combine each object with low freq objects
        double pairDist = 0;
        set<int>selected;
        int mask = 0;

        vector<pair<int, int> >keywordscnt;
        for(unsigned i = 0; i < keywordsnum; i++)
            keywordscnt.push_back( make_pair(0, i) );

        for(unsigned i = 0;i < Objnum;i++){
            for(unsigned j = 0; j < keywordsnum; j++)
                if(Obj[i].mask & (1<<j))
                    keywordscnt[j].first++;
            if(Obj[i].mask & (mask ^ keywordsBM)){
                for(set<int>::iterator it = selected.begin(); it != selected.end(); it++){
                    pairDist = max(pairDist, Objdist(Obj[*it], Obj[i]));
                }
                selected.insert(i);
                mask |= Obj[i].mask;
            }
        }
        update(pairDist);
        update(pairDist, selected);

        sort(keywordscnt.begin(), keywordscnt.end());
        for(unsigned i = 0; i < keywordsnum; i++)
            keywordsFreq.push_back(keywordscnt[i].second);

        unsigned minKeywordFreqIndex = keywordscnt[0].second;
        unsigned maxKeywordFreqIndex = keywordscnt[keywordsnum-1].second;

#ifdef DEBUG
        cerr<<"[DEBUG]Min freq wordcount: "<< keywordscnt[0].first <<endl;
#endif

        vector<Object>lowFreqObj;
        for(unsigned i = 0;i < Objnum; i++)
            if(Obj[i].mask & (1<<minKeywordFreqIndex))
                lowFreqObj.push_back( Obj[i] );
        this->maxKeywordFreqIndex = maxKeywordFreqIndex;

        int delcount = 0;
        vector<pair<double, int> >candidate_pivot;
        bool opt = lowFreqObj.size() < 1000;
        for(unsigned pivot = 0; pivot < Objnum; pivot++){
            //if low-freq objects no too much
            //remove from data set
            double infreqDist = -1;
            if(opt && (infreqDist = combinationCheck(pivot, lowFreqObj)) > bestdist() ){
                grid.del(Obj[pivot]);
                delcount++;
                continue;
            }
            else{
                candidate_pivot.push_back(make_pair(infreqDist, pivot) );
            }
        }
        sort(candidate_pivot.begin(), candidate_pivot.end());

#ifdef DEBUG
        cerr<<"[DEBUG]Delete:\t"<< delcount <<endl;
        cerr<<"[DEBUG]Left:\t"<<candidate_pivot.size()<<endl;
#endif

        double low  = 0;
        double high = bestdist();
        double eps  = 1e-2;

        //don't need uncessary check
        vector<double> maxInvildDiameter(Obj.size(), 0.0);

        int lastpivot = -1;
        while(high - low > eps){
            //timeout
            double mid = (high + low) / 2;
#ifdef DEBUG
            //cerr << mid << " - " << high << " " << low << endl;
            //cerr << "[DEBUG]Delete:\t" << delcount << endl;
#endif
            bool found = false;
            for(unsigned i = 0; i < candidate_pivot.size(); i++){
                int pivot = candidate_pivot[i].second;
                if(opt){
                    if(candidate_pivot[i].first > high){
                        candidate_pivot[i].first = -1;
                        grid.del(Obj[pivot]);
                        delcount++;
                        continue;
                    }
                    else if(candidate_pivot[i].first < 0){
                        continue;
                    }
                }
                if(Obj[pivot].mask == (1 << maxKeywordFreqIndex)){
                    continue;
                }

                //if only one object
                if(Obj[pivot].mask == keywordsBM){
                    set<int>group;
                    group.insert(pivot);
                    update(0.0, group);
                    continue;
                }

                if(mid < maxInvildDiameter[pivot])
                    continue;

                if( sweep(pivot, mid, false, false) ){
                    lastpivot = pivot;
                    high = mid;
                    found = true;
                    break;
                }
                else{
                    maxInvildDiameter[pivot] = max(maxInvildDiameter[pivot], mid);
                }
            }
            if(!found){
                low = mid;
            }
        }
        if(!isexact && lastpivot != -1){
            sweep(lastpivot, high, false, true);
        }
        else{
            if(lastpivot != -1){
                sweep(lastpivot, high, false, true);
            }
            ansLowerbound = low * lambda;
            double range = high / lambda;
            double bestval = bestdist();
            for(unsigned i = 0; i < candidate_pivot.size(); i++){
                int pivot = candidate_pivot[i].second;
                if(opt){
                    if(candidate_pivot[i].first > bestval){
                        candidate_pivot[i].first = -1;
                        grid.del(Obj[pivot]);
                        delcount++;
                        continue;
                    }
                }
            }

            for(unsigned i = 0; i < candidate_pivot.size(); i++){
                int pivot = candidate_pivot[i].second;
                if(opt){
                    if(candidate_pivot[i].first < 0){
                        continue;
                    }
                }
                if(Obj[pivot].mask == (1 << maxKeywordFreqIndex)){
                    continue;
                }

                if(range < maxInvildDiameter[pivot])
                    continue;
                sweep(pivot, range, true);
            }
        }
    }
};
#endif
