#ifndef _QUERYGEN_
#define _QUERYGEN_

#include "../lib/sweepcircle.h"

void genquery(int seednum){

}

#endif
