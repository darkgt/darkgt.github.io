#ifndef _TOOLS_H_
#define _TOOLS_H_

#include <map>
#include <cmath>
#include <vector>
#include <string>
#include <ctime>
#include <sys/resource.h>

using namespace std;

typedef struct Object
{
	double x,y;
	unsigned int mask;
	int id;
	int oid;
	friend bool operator<(const struct Object &a, const struct Object &b){
		return a.x < b.x;
	}
}Object;

class Grid{
protected:
	double range_left, range_right, range_up, range_down;
    int pointnum;
	vector<Object>point;
	vector<Object> **grid;
	int gridx, gridy;//grid size
public:
	double length;//each grid size length*length
	inline double dist(double x1, double y1, double x2, double y2){
		return sqrt( (x1-x2)*(x1-x2) + (y1-y2)*(y1-y2) );
	}
	Grid(){
		grid = NULL;
		point.clear();
		pointnum = 0;
	}
	virtual ~Grid(){
		point.clear();
		if(grid == NULL)
			return;
		for(int i = 0; i < gridx; i++){
			for(int j = 0; j < gridy; j++){
				if(grid!=NULL && grid[i] != NULL)
					grid[i][j].clear();
			}
			if(grid[i] != NULL)
				delete[] grid[i];
		}
		if(grid != NULL)
			delete[] grid;
	}
	void insert(Object add){
		add.id = pointnum++;
		point.push_back(add);
	}
	void clear(){
		pointnum = 0;
		if(grid != NULL){
			for(int i=0;i<gridx;i++){
				if(grid[i] != NULL){
					for(int j=0;j<gridy;j++)
						grid[i][j].clear();
					delete[] grid[i];
				}
			}
			delete[] grid;
		}
	}
	void init(){
		if(point.size() == 0)
			return;
		range_left = range_right = point[0].x;
		range_up = range_down = point[0].y;
		for(unsigned i = 1; i < point.size(); i++){
			range_left = min(range_left, point[i].x);
			range_right = max(range_right , point[i].x);
			range_up = max(range_up, point[i].y);
			range_down = min(range_down, point[i].y);
		}

		if(point.size() == 1){
			length = 0.1;
			gridx = gridy = 1;
		}
		else{
			length = (range_right - range_left + range_up - range_down) / 2 / pow(1.0*pointnum, 0.25);
			gridx = ceil((range_right - range_left) / length);
			gridy = ceil((range_up - range_down) / length);
		}

		grid = new vector<Object>*[gridx];
		for(int i =0;i<gridx;i++){
			grid[i] = new vector<Object>[gridy];
		}
		for(unsigned i = 0; i < point.size(); i++){
			int x = floor( (point[i].x - range_left) / length );
			int y = floor( (point[i].y - range_down) / length );
			grid[x][y].push_back(point[i]);
		}
		point.clear();
	}

	//delete objects in grid 
	bool del(Object obj){
		int x = floor( (obj.x - range_left) / length );
		int y = floor( (obj.y - range_down) / length );
		for(unsigned i = 0; i < grid[x][y].size(); i++){
			if(grid[x][y][i].oid == obj.oid){
				grid[x][y].erase(grid[x][y].begin() + i);
				return true;
			}
		}
		return false;
	}

	//won't return the query object with the bitmask limitation
	vector<int> query(double x, double y, double r, int mask){
		vector<int>ret;
		int count = 0;
		for(int i=0;i<gridx;i++){
			double left = range_left + i * length;
			double right = left + length;
			if( right < x-r || left > x+r )
				continue;
			for(int j=0;j<gridy;j++){
				double down = range_down + j * length;
				double up = down + length;
				if( up < y-r || down > y+r )
					continue;
				for(unsigned k = 0;k<grid[i][j].size();k++){
					Object *p = &grid[i][j][k];
					if((p->mask & mask)&&dist(x,y,p->x,p->y) < r)
						ret.push_back(p->id);
					count++;
				}
			}
		}
		//cerr<<count<<endl;
		return ret;
	}
	vector<int> query(double x, double y, double r, int mask, double queryx, double queryy, double furthest){
		vector<int>ret;
		int count = 0;
		for(int i=0;i<gridx;i++){
			double left = range_left + i * length;
			double right = left + length;
			if( right < x-r || left > x+r )
				continue;
			for(int j=0;j<gridy;j++){
				double down = range_down + j * length;
				double up = down + length;
				if( up < y-r || down > y+r )
					continue;
				for(unsigned k = 0;k<grid[i][j].size();k++){
					Object *p = &grid[i][j][k];
					if((p->mask & mask)&&dist(x,y,p->x,p->y) < r){
						//different
						if(dist(queryx, queryy, p->x, p->y) < furthest)
							ret.push_back(p->id);
					}
					count++;
				}
			}
		}
		return ret;
	}
};

typedef unsigned int KEYTYPE; //if more keywords, should use long or long long

typedef union{
	struct{
	public:
		int mbrID, wordsID;
	};
	long long key;
} KeyID;

class Query
{
public:
	Query() {x=0.0; y=0.0;text = "";}
	
	Query(string text, double x , double y)
	{
		this->text = text;
		this->x = x;
		this->y = y;
	}
	string text;
	double x, y;
};

template<class _Ty>
struct NodeValueLess : std::binary_function<_Ty, _Ty, bool> {
       bool operator()(_Ty *_X, _Ty *_Y) const
	   {return _Ty::CompareValueLess(_X, _Y); }
};

void getCurTime(rusage* curTime){
    if(getrusage(RUSAGE_SELF, curTime) != 0){
        fprintf(stderr, "The running time info couldn't be collected successfully.\n");
        exit(0);
    }
}

void getTime( struct rusage* timeStart, struct rusage* timeEnd, double* userTime, double* sysTime)
{
    (*userTime) = ((double)(timeEnd->ru_utime.tv_sec - timeStart->ru_utime.tv_sec)) + 
        ((double)(timeEnd->ru_utime.tv_usec - timeStart->ru_utime.tv_usec)) * 1e-6;
    (*sysTime) = ((double)(timeEnd->ru_stime.tv_sec - timeStart->ru_stime.tv_sec)) +
        ((double)(timeEnd->ru_stime.tv_usec - timeStart->ru_stime.tv_usec)) * 1e-6;
}

#endif
