#ifndef _PROBLEM3_
#define _PROBLEM3_

#include <iostream>
#include <SpatialIndex.h>
#include <map>
#include <set>
#include <vector>
#include <cmath>
#include "Tool.h"
#include "data.h"
#include "btree.h"
#include "IBRtree.h"
#include "SearchIBRTree.h"

using namespace std;

extern string textFile;
extern string locFile;
extern string invertedFile;
extern string subdocFolder;
extern string btreeFolder;
extern string treeFile;

extern int numOfEntry;
extern double alpha;

#define DEBUG
#define TIMEOUT

class Problem3Appr : public SpatialIndex::IQueryStrategy
{
private:	
	priority_queue<RTreeNode *, deque<RTreeNode *>, NodeValueLess<RTreeNode> > queueNode;	
	Query *Q;
	int nodeNum;
	vector<int> keywords;
	KEYTYPE keywordsBM;	
	vector<int> group;
	double cost;
	map<int, Point> objLoc;
	bool usedInAPP2;
				
public:

	Query furthestObj;		//this structure is used for the second approximate algorithm
	
	Problem3Appr(Query *Q, int nodeNum, bool usedInAPP2=false)
	{
		this->Q = Q;
		this->nodeNum = nodeNum;

		istringstream iss(Q->text);
		int wid; char c;
		while(iss>>wid)
		{
			keywords.push_back(wid);
			iss>>c;
		}

		keywordsBM = (1 << keywords.size()) - 1;
		cost = 0;
		this->usedInAPP2 = usedInAPP2;
	}

	~Problem3Appr()
	{
		while( !queueNode.empty())
		{
			RTreeNode *p = queueNode.top();
			queueNode.pop();
			delete p;
		}
	}

	friend ostream& operator<<(ostream& out,Problem3Appr & t)    
	{
		out<<t.getCost()<<":";
		vector<int>::iterator iter = t.group.begin();
		for(; iter != t.group.end(); ++iter)
			out<<*iter<<" ";
		out<<endl;
		return out;
	}

	void setQuery(Query *Q)
	{
		this->Q = Q;
	}

	double getCost(vector<int> *objs = NULL)
	{
		double maxDiam = 0;
		for(int i=0;i<group.size();i++)
		{
			int o1 = group[i];
			if (objs != NULL)	objs->push_back(o1);
			for(int j=i+1;j<group.size();j++)
			{
				int o2 = group[j];
				double x1 = objLoc[o1].m_pCoords[0], y1 = objLoc[o1].m_pCoords[1];
				double x2 = objLoc[o2].m_pCoords[0], y2 = objLoc[o2].m_pCoords[1];
				double dist = sqrt( (x1-x2) * (x1-x2) + (y1-y2) * (y1-y2));
				if(dist > maxDiam)
					maxDiam = dist;
			}
		}
		return alpha * cost + (1-alpha) * maxDiam;
	}

	vector<int> getGroup()
	{
		return group;
	}

	double getRes(Query *oriQ,vector<int> *objs)	//this function is used in the second approximate algorithm
	{
		double res=0, maxDist=0, maxDiam=0;		
		for(int i=0;i<group.size();i++)
		{
			int o1 = group[i];
			double x1 = objLoc[o1].m_pCoords[0], y1 = objLoc[o1].m_pCoords[1];
			objs->push_back(o1);
			double dist = sqrt( (x1-oriQ->x) * (x1-oriQ->x) + (y1-oriQ->y) * (y1-oriQ->y));
			if(dist > maxDist)
				maxDist = dist;

			for(int j=i+1;j<group.size();j++)
			{
				int o2 = group[j];
				double x2 = objLoc[o2].m_pCoords[0], y2 = objLoc[o2].m_pCoords[1];
				double dist = sqrt( (x1-x2) * (x1-x2) + (y1-y2) * (y1-y2));
				if(dist > maxDiam)
					maxDiam = dist;
			}
		}
		res = alpha * maxDist + (1-alpha) * maxDiam;
		return res;
	}

	void getNextEntry(const IEntry& entry, id_type& nextEntry, bool& hasNext)
	{	
		const INode* n = dynamic_cast<const INode*>(&entry);

		if (n != 0)
		{
			int pid = n->getIdentifier();
			string btFile = btreeFolder + MyTool::IntToString(pid);
			char *btfname = new char[btFile.size()+1];
			memcpy(btfname, btFile.c_str(), btFile.size());		
			btfname[btFile.size()] = '\0';
			BTree *bt = new BTree(btfname, 0);	
			
			map<int, vector<int>*> objectTexts;		//the text description of an object
			set<int> indexID;						//the id of child nodes which contains query keywords				
			map<int, vector<int>*>::iterator iterMap;
			for(unsigned int k=0;k<keywords.size();k++)
			{
				int wordID = keywords[k];
				VECTYPE *data = new VECTYPE[DIMENSION];
				bool flag = bt->search(wordID, &data);
				if(flag)
				{					
					for(int i=0;i<DIMENSION;i++)
					{
						if(data[i] > 0)							
						{
							unsigned char mask = 1;
							for(int j=0;j<8;j++)
							{
								if((data[i] & mask) > 0)
								{
									int index = i*8+j;
									indexID.insert(index);
									iterMap = objectTexts.find(index);
									if(iterMap ==  objectTexts.end())
									{
										vector<int> *p = new vector<int>();		
										p->push_back(k);
										objectTexts[index] = p;
									}
									else
									{
										vector<int> *p = iterMap->second;
										p->push_back(k);
									}
								}
								mask = mask << 1;
							}
						}
					}
				}
				delete data;
			}
			delete bt;
			delete btfname;

			set<int>::iterator si = indexID.begin();
			for(;si != indexID.end(); ++si)	
			{
				uint32_t cChild = *si;
				int cid = n->getChildIdentifier(cChild);
				
				IShape *out;
				n->getChildShape(cChild, &out);
				Region* pr = dynamic_cast<Region *>(out);	

				double dx = Q->x - pr->m_pHigh[0];
				double dy = Q->y - pr->m_pHigh[1];											

				int key = MyTool::ConvertToInt(objectTexts[cChild]);
				if( (key & keywordsBM) == 0)
					continue;

				double dist;
				RTreeNode *rtp = new RTreeNode;

				if(n->isLeaf())
				{
					dist = sqrt(dx * dx + dy * dy);
					rtp->isNode = false;
				}
				if(n->isIndex())
				{
					double coor[2];
					coor[0] = Q->x; coor[1] = Q->y;
					Point pt(coor, 2);

					dist = MyTool::ComputeMinPossible(pr, &pt);
					rtp->isNode = true;
				}
				
				rtp->identifier = n->getChildIdentifier(cChild);
				rtp->minValue = dist;
				rtp->bitmap = MyTool::ConvertToInt(objectTexts[cChild]);
				rtp->pr = pr;

				queueNode.push(rtp);
			}
			map<int, vector<int>*>::iterator oi = objectTexts.begin();
			for(; oi != objectTexts.end(); ++oi)
			{
				vector<int> *p = oi->second;
				delete p;
			}
		}

		if (!queueNode.empty())		
		{			
			while (!queueNode.empty())
			{
				RTreeNode *p = queueNode.top();
				queueNode.pop();

				if( p->isNode )		//if the node is not an object, we read the next page.
				{	
					KEYTYPE keyValue = p->bitmap;
					if( (keyValue & keywordsBM) > 0)
					{
						nextEntry = p->identifier;
						hasNext = true;
						delete p;
						break;
					}
				}
				else
				{
					KEYTYPE key = p->bitmap;
					int interS = key & keywordsBM;
					if(interS > 0)//contains some keywords that have not been covered
					{
						group.push_back(p->identifier);

						if(keywordsBM == (1 << keywords.size()) - 1){
							cost = p->minValue;
						}

						keywordsBM = keywordsBM - interS;
						double coor[2];
						coor[0] = p->pr->m_pLow[0];
						coor[1] = p->pr->m_pLow[1];
						Point pp(coor,2);
						objLoc[p->identifier] = pp;

						if(keywordsBM == 0)
						{
							hasNext = false;
							//the following code is for the second approximate algorithm
							if(usedInAPP2)
							{
								furthestObj.x = p->pr->m_pLow[0];
								furthestObj.y = p->pr->m_pLow[1];
								KEYTYPE mask = 1;
								for(int i=0;i<sizeof(KEYTYPE) * 8;i++)
								{
									if( (interS & mask) > 0)
									{
										furthestObj.text = MyTool::IntToString(keywords[i]);
										//any word is OK, used for finding next nearest object
										break;
									}
									mask = mask << 1;
								}
							}
							delete p;
							break;
						}
					}
				}
				delete p;
			}
		}
	
		else 
			hasNext = false;
	}
};

class Problem3Exact
{
protected:
	Query *Q;
	vector<int> keywords;
	int keywordsnum;
	vector<Object>Obj;
	
	Grid grid;
	unsigned int keywordsBM;//bitmap
	unsigned int maxKeywordFreqIndex;

	double bestcost;//result
	set<int>result;

	map<int, vector<int> >invertedFile; //keywords -> id
	map<int, pair<double, double> >invertedLoc; //id -> location

	//Test Function
	clock_t start, end;
	double timeout;
	vector<int> keywordsFreq;

	double Objdist(const Object &a,const Object &b){
		return  sqrt( (a.x-b.x)*(a.x-b.x) + (a.y-b.y)*(a.y-b.y) );
	}

	double Querydist(const Object &a){
		return sqrt( (a.x-Q->x) * (a.x-Q->x) + (a.y-Q->y) * (a.y-Q->y) );
	}

	virtual inline bool update(double cost){
		bestcost = cost + 0.01;
		return true;
	}
	virtual inline bool update(double cost, const set<int>&group){
		if(cost < bestcost){
			bestcost = cost;
			result = group;
			return true;
		}
		return false;
	}
	virtual inline double bestdist(){
		return bestcost;
	}
public:
	inline bool istimeout(){
		end = clock();
		return (end-start) / CLOCKS_PER_SEC > timeout;
	}

	unsigned int Objnum;

	void show(ostream &out = std::cerr){
		out<< bestdist()/2 <<" : ";
		double dist = 0;
		double nearest = 1e10;
		int mask = 0;

		for(set<int>::iterator i =result.begin();i!=result.end();i++){
			mask |= Obj[*i].mask;
			for(set<int>::iterator j =result.begin();j!=result.end();j++){
				double len = Objdist(Obj[*i],Obj[*j]);
				if(len>dist)dist = len;
				len = Querydist(Obj[*i]);
				if(len < nearest) nearest = len;
			}
		}
		
		#ifdef DEBUG
		cerr<<"[DEBUG]review:\n"<<(dist + nearest)/2<<" mask:"<<mask<<"\n";
		#endif

		for(set<int>::iterator i=result.begin();i!=result.end();i++)
			out<<Obj[*i].oid<<" ";
		out<<endl;
	}

	void Test(Query *Q, int nodeNum)
	{
		timeout = 5 * 60;
		start = clock();

		this->Q = Q;
		
		IBRTree *rt = new IBRTree();
		rt->ReadTree();
		Problem3Appr pb3a(Q, nodeNum);
		rt->GetTree()->queryStrategy(pb3a);
		double cost = pb3a.getCost();

		update(cost * 2);
		delete rt;

		istringstream iss(Q->text);
		int wid; char c;
		keywords.clear();
		while(iss>>wid)
		{
			keywords.push_back(wid);
			iss>>c;
		}
		keywordsnum = keywords.size();
		keywordsBM = (1 << keywords.size())-1;
		
		Obj.clear();
		grid.clear();
		result.clear();

		#ifdef DEBUG
		cerr<<"[DEBUG]Initial Cost by Appr Algo:"<<bestdist()/2<<endl;
		#endif
		//cerr<<bestdist()/2<<endl;
		SearchIBRTree ss(Q, nodeNum, -1, bestdist());
		IBRTree irtree;
		irtree.ReadTree();
		irtree.GetTree()->queryStrategy(ss);
		
		vector<Object>::iterator iter;
		for(iter = ss.res.begin(); iter != ss.res.end(); iter++){
			//cerr<<iter->second.oid<<" "<<iter->second.mask<<" "<<iter->second.x<<","<<iter->second.y<<endl;
			Obj.push_back(*iter);
			grid.insert(*iter);
		}
		Objnum = Obj.size();

		#ifdef DEBUG
		cerr<<"[DEBUG]Object num: "<<Objnum<<endl;
		#endif

		grid.init();
		Process();
	}

	Problem3Exact(){}

	~Problem3Exact()
	{
	}

	virtual void search(const vector<int>&curset, set<int>selected, int mask, double pairdist, double nearest, int inc){
		#ifdef TIMEOUT
		if(istimeout()) return;
		#endif
		if(mask == keywordsBM){
			if(pairdist + nearest < bestdist()){
				update(pairdist + nearest, selected);
			}
			return ;
		}
		if(pairdist + nearest > bestdist())
			return;
		vector<int>nextset;
		vector<double>nextlen;
		int nextmask = 0;
		for(vector<int>::const_iterator i = curset.begin(); i!= curset.end(); i++){
			if( (Obj[*i].mask & (keywordsBM^mask)) == 0 )
				continue;
			if( Obj[*i].oid < inc )
				continue;
			double len = pairdist;
			for(set<int>::const_iterator j=selected.begin();j!=selected.end();j++){
				double dist = Objdist(Obj[*i], Obj[*j]);
				if(len < dist){
					len = dist;
				}
			}
			if(nearest + len > bestdist())
				continue;
			nextlen.push_back(len);
			nextset.push_back(*i);
			nextmask |= Obj[*i].mask;
		}

		if( (nextmask|mask) != keywordsBM)
			return;

		for(unsigned i = 0; i < nextset.size(); i++){
			int id = nextset[i];
			selected.insert(id);
			search(nextset, selected, mask | Obj[id].mask, max(nextlen[i], pairdist), nearest, Obj[id].oid);
			selected.erase(id);
		}
	}

	//enumerate the nearest object to fix the second cost
	//select the nearest object then search
	void checkcircle(const vector<int>& candidates, const vector<int>& selectedSet, double qdist){
		#ifdef TIMEOUT
		if(istimeout()) return;
		#endif
		int basemask = 0;
		set<int> selected;
		double selectedPairDist = 0.0;
		for(unsigned i = 0; i < selectedSet.size(); i++){
			qdist = min(qdist, Querydist(Obj[selectedSet[i]]));
			basemask |= Obj[ selectedSet[i] ].mask;
			selected.insert(selectedSet[i]);

			for(unsigned j = i+1; j < selectedSet.size(); j++){
				selectedPairDist = max(selectedPairDist, Objdist(Obj[selectedSet[i]], Obj[selectedSet[j]]));
			}
		}

		vector<pair<double, int> > obj_by_dist;
		for(vector<int>::const_iterator it = candidates.begin(); it != candidates.end(); it++){
			//if(Obj[*it].mask & (keywordsBM ^ basemask))
			if(selected.count(*it) > 0)
				continue;
			obj_by_dist.push_back(make_pair(Querydist(Obj[*it]), *it));
		}

		int checkmask = basemask;
		sort( obj_by_dist.begin(), obj_by_dist.end(), greater<pair<double, int> >() );
		vector<int>nextset;

		if(checkmask == keywordsBM){
			search(nextset, selected, basemask, selectedPairDist, qdist, 0);
		}

		for(unsigned i = 0; i < obj_by_dist.size(); i++){
			#ifdef TIMEOUT
			if(istimeout()) return;
			#endif

			double dist = obj_by_dist[i].first;
			int idx = obj_by_dist[i].second;

			//if(min(qdist, dist) + Objdist(Obj[idx], Obj[selectedSet[0]]) > bestdist())
				//continue;

			nextset.push_back(idx);
			checkmask |= Obj[idx].mask;

			//pruning
			if(i + 1 < obj_by_dist.size() &&  obj_by_dist[i+1].first > qdist)
				continue;

			if(checkmask == keywordsBM){
				if(dist > qdist){ //This object is not the nearest
					search(nextset, selected, basemask, selectedPairDist, qdist, 0);
				}
				else{ //This object is the nearest
					selected.insert(idx);
					double pairDist = selectedPairDist;
					for(unsigned i = 0; i < selectedSet.size(); i++)
						pairDist = max(pairDist, Objdist(Obj[selectedSet[i]], Obj[idx]));
					search(nextset, selected, basemask|Obj[idx].mask, pairDist, min(qdist, dist), 0);
					selected.erase(idx);
				}
			}
		}
	}

	/*
		Low frequency keywords based algorithm
	*/
	void Process(){
		//try to combine with low freq objects
		vector<pair<int, int> >keywordscnt;
		for(unsigned i = 0; i < keywordsnum; i++)
			keywordscnt.push_back( make_pair(0, i) );

		for(unsigned i = 0;i < Objnum;i++)
			for(unsigned j = 0; j < keywordsnum; j++)
				if(Obj[i].mask & (1<<j))
					keywordscnt[j].first++;
		sort(keywordscnt.begin(), keywordscnt.end());
		for(unsigned i = 0; i < keywordsnum; i++)
			keywordsFreq.push_back(keywordscnt[i].second);

		unsigned minKeywordFreqIndex = keywordscnt[0].second;
		unsigned maxKeywordFreqIndex = keywordscnt[keywordsnum-1].second;
		
		#ifdef DEBUG
		cerr<<"[DEBUG]Min freq wordcount: "<< keywordscnt[0].first <<endl;
		#endif

		vector<pair<double, int> >lowFreqIndex;
		for(unsigned i = 0;i < Objnum; i++)
			if(Obj[i].mask & (1<<minKeywordFreqIndex)){
				lowFreqIndex.push_back( make_pair(Querydist(Obj[i]), i) );
			}
		sort(lowFreqIndex.begin(), lowFreqIndex.end());

		this->maxKeywordFreqIndex = maxKeywordFreqIndex;

		for(unsigned i = 0; i < lowFreqIndex.size(); i++){
			vector<int>selectedSet;
			int id = lowFreqIndex[i].second;
			selectedSet.push_back(id);
			vector<int>candidates;
			int mask = Obj[id].mask;
			if(Querydist(Obj[id]) > bestdist())
				continue;
			for(unsigned j = 0; j < Objnum; j++){
				//if( (Obj[j].mask & (keywordsBM ^ Obj[id].mask)) == 0 )
					//continue;

				//if( min(Querydist(Obj[id]), Querydist(Obj[j])) + Objdist(Obj[id], Obj[j]) > bestdist())
				//	continue;
				if( Objdist(Obj[id], Obj[j]) > bestdist() )
					continue;
				if( Querydist(Obj[j]) > bestdist() )
					continue;
				candidates.push_back(j);
				mask |= Obj[j].mask;
			}
			if(mask != keywordsBM)
				continue;

			#ifdef DEBUG
			if(candidates.size())
				cerr<<"[DEBUG]Candidate Number:"<<candidates.size()<<endl;
			#endif

			checkcircle(candidates, selectedSet, Querydist(Obj[id]));
		}
	}
};

class Problem3Topk: public Problem3Exact
{
protected:
	priority_queue<pair<double, set<int> > >Topk;
	int ksize;
	inline bool update(double cost, const set<int>& group){
		if(Topk.size() < ksize){
			Topk.push(make_pair(cost, group));
			return true;
		}
		else{
			if(Topk.top().first < cost){
				return false;
			}
			else{
				Topk.push(make_pair(cost, group));
				Topk.pop();
				return true;
			}
		}
	}
	inline bool update(double cost){
		set<int>group; //empty set, just for update, should not be a real result!!
		return update(cost + 0.1, group);
	}
	inline double bestdist(){
		if(Topk.empty())
			return -1.0;
		if(Topk.size()<ksize)
			return Topk.top().first;
		return Topk.top().first;
	}
public:
	void show(ostream &out = std::cerr){
		priority_queue<pair<double, set<int> > > res = Topk;
		while(!res.empty()){
			pair<double, set<int> >cur = res.top();
			res.pop();
			double dist = 0;
			double furthest = 0;
			int mask = 0;
			set<int> result = cur.second;
			if(result.size() == 0)
				continue;
			for(set<int>::iterator i =result.begin();i!=result.end();i++){
				mask |= Obj[*i].mask;
				for(set<int>::iterator j =result.begin();j!=result.end();j++){
					double len = Objdist(Obj[*i],Obj[*j]);
					if(len>dist) dist = len;
					len = Querydist(Obj[*i]);
					if(len>furthest)furthest = len;
				}
			}
			
			out<<"Top-"<<res.size() + 1<<" : "<<cur.first/2<<" :";
			#ifdef DEBUG
			cerr<<"[DEBUG]review:\n"<<(dist+furthest)/2<<" mask:"<<mask<<"\n";
			#endif
			for(set<int>::iterator i=result.begin();i!=result.end();i++)
				out<<Obj[*i].oid<<" ";
			out<<endl;
		}
		out<<endl;
	}
	
	Problem3Topk(){}
	
	~Problem3Topk(){}

	void TopkTest(Query *Q, int nodeNum, IBRTree *irtree, int ksize){
		this->ksize = ksize;
		while(!Topk.empty())
			Topk.pop();
		Test(Q, nodeNum, irtree);
	}

	set<Object> vec2set(vector<Object>vt){
		set<Object> ret;
		for(unsigned i = 0;i < vt.size(); i++)
			ret.insert(vt[i]);
		return ret;
	}

	void Test(Query *Q, int nodeNum, IBRTree *irtree)
	{
		timeout = 5 * 60;
		start = clock();

		this->Q = Q;

		MinmaxTopkAppr topkappr;
		topkappr.Test(Q, nodeNum, ksize, irtree);//
		vector<vector<Object> >apprResult = topkappr.getResult();

		for(unsigned i = 0;i < ksize; i++){
			update(topkappr.getCost(apprResult[apprResult.size() - 1]) * 2);
		}
		
		istringstream iss(Q->text);
		int wid; char c;
		keywords.clear();
		while(iss>>wid)
		{
			keywords.push_back(wid);
			iss>>c;
		}
		keywordsnum = keywords.size();
		keywordsBM = (1 << keywords.size())-1;
		
		Obj.clear();
		grid.clear();
		result.clear();

		#ifdef DEBUG
		cerr<<"[DEBUG]"<<bestdist()/2<<endl;
		#endif

		SearchIBRTree ss(Q, nodeNum, -1, bestdist());
		irtree->ReadTree();
		irtree->GetTree()->queryStrategy(ss);
		
		vector<Object>::iterator iter;
		for(iter = ss.res.begin(); iter != ss.res.end(); iter++){
			//cerr<<iter->second.oid<<" "<<iter->second.mask<<" "<<iter->second.x<<","<<iter->second.y<<endl;
			Obj.push_back(*iter);
			grid.insert(*iter);
		}
		Objnum = Obj.size();
		#ifdef DEBUG
		cerr<<"[DEBUG]Object num: "<<Objnum<<endl;
		#endif
		grid.init();
		Process();
	}

};

#endif