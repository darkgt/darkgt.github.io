#ifndef _PROBLEM1EXACT_
#define _PROBLEM1EXACT_

#include <iostream>
#include <SpatialIndex.h>
#include <map>
#include <set>
#include <vector>
#include "Tool.h"
#include "data.h"
#include "btree.h"

using namespace std;

extern string textFile;
extern string locFile;
extern string invertedFile;
extern string subdocFolder;
extern string btreeFolder;

void GenerateSubSets(vector<int> &intersect, set<KEYTYPE> &res)
{	
	int L = intersect.size();

	//unsigned long length = pow(2.0, L);
	unsigned long length = 1 << L;
	for(unsigned int i=1;i<length;i++)
	{
		unsigned int p = 0;
		unsigned int mask = 0x1;
		for(int j=0;j<L;j++)
		{
			p+= (mask & i) << (intersect[j] - j);
			mask = mask << 1;
		}
		res.insert(p);
	}
}	



bool compareNode(RTreeNode *a, RTreeNode *b)
{
	return a->minValue > b->minValue;
}

///* approximation algorithm
class Problem1Appr : public SpatialIndex::IQueryStrategy
{
private:	
	vector<RTreeNode *> heapNode;	
	Query *Q;
	int nodeNum;
	vector<int> keywords;
	KEYTYPE keywordsBM;			//keywords bitmask
	set<int> group;
	double Cost;
	map<int, double> objectDist;
				
public:

	double ComputeCost()
	{
		double res = 0.0;
		set<int>::iterator si;
		for(si = group.begin(); si != group.end(); ++si)
			res += objectDist[*si];
		return res;
	}

	friend ostream& operator<<(ostream& out,Problem1Appr & t)    
	{
		out<<t.ComputeCost()<<":";
		set<int>::iterator iter = t.group.begin();
		for(; iter != t.group.end(); ++iter)
			out<<*iter<<" ";
		out<<endl;
		return out;
	}
	
	Problem1Appr(Query *Q, int nodeNum)
	{
		this->Q = Q;
		this->nodeNum = nodeNum;		

		istringstream iss(Q->text);
		int wid; char c;
		while(iss>>wid)
		{
			keywords.push_back(wid);
			iss>>c;
		}

		keywordsBM = pow(2.0, (int)keywords.size())-1;
		Cost = 0;
	}
	
	~Problem1Appr()
	{
		while (!heapNode.empty())
		{
			RTreeNode *p = heapNode.back();
			heapNode.pop_back();
			delete p;
		}

	}

	void getNextEntry(const IEntry& entry, id_type& nextEntry, bool& hasNext)
	{	
		const INode* n = dynamic_cast<const INode*>(&entry);

		if (n != 0)
		{
			int pid = n->getIdentifier();
			string btFile = btreeFolder + MyTool::IntToString(pid);
			char *btfname = new char[btFile.size()+1];
			memcpy(btfname, btFile.c_str(), btFile.size());		
			btfname[btFile.size()] = '\0';
			BTree *bt = new BTree(btfname, 0);	
			
			map<int, vector<int>*> objectTexts;		//the text description of an object
			set<int> indexID;						//the id of child nodes which contains query keywords				
			map<int, vector<int>*>::iterator iterMap;
			for(unsigned int k=0;k<keywords.size();k++)		
								// Find all the object that contain the query keywords, and created an inverted list								
								// in this list, the position of an object is used, instead of the object's ID
			{
				int wordID = keywords[k];
				unsigned char *data = new unsigned char[DIMENSION];
				bool flag = bt->search(wordID, &data);
				if(flag)
				{					
					for(int i=0;i<DIMENSION;i++)
					{
						if(data[i] > 0)							
						{
							unsigned char mask = 1;
							for(int j=0;j<8;j++)
							{
								if((data[i] & mask) > 0)
								{
									int index = i*8+j;
									indexID.insert(index);
									iterMap = objectTexts.find(index);
									if(iterMap ==  objectTexts.end())
									{
										vector<int> *p = new vector<int>();
										p->push_back(k);		//the index of the word in keywords, not the real word id!
										objectTexts[index] = p;
									}
									else
									{
										vector<int> *p = iterMap->second;
										p->push_back(k);
									}
								}
								mask = mask << 1;
							}
						}
					}
				}
				delete data;
			}
			delete bt;
			delete btfname;

			set<int>::iterator si = indexID.begin();
			for(;si != indexID.end(); ++si)	
			{
				uint32_t cChild = *si;
				int cid = n->getChildIdentifier(cChild);
				
				IShape *out;
				n->getChildShape(cChild, &out);
				Region* pr = dynamic_cast<Region *>(out);	

				double dx = Q->x - pr->m_pHigh[0];
				double dy = Q->y - pr->m_pHigh[1];											

				KEYTYPE key = MyTool::ConvertToInt(objectTexts[cChild]);
				KEYTYPE interS = key & keywordsBM;
				if( interS == 0)		//no uncovered keywords contained
				{
					delete pr;
					continue;
				}

				double dist;
				RTreeNode *rtp = new RTreeNode;
				
				if(n->isLeaf())
				{
					dist = sqrt(dx * dx + dy * dy);
					objectDist[n->getChildIdentifier(cChild)] = dist;
					rtp->isNode = false;
				}
				if(n->isIndex())
				{
					double coor[2];
					coor[0] = Q->x; coor[1] = Q->y;
					Point pt(coor, 2);

					dist = MyTool::ComputeMinPossible(pr, &pt);
					rtp->pr = pr;
					rtp->isNode = true;
				}
				
				rtp->identifier = n->getChildIdentifier(cChild);
				rtp->bitmap = interS;
				int num = MyTool::getNumOf1(interS);
				rtp->minValue = dist/num;

				heapNode.push_back(rtp);
				push_heap(heapNode.begin(), heapNode.end(), compareNode);
			}

			map<int, vector<int>*>::iterator oi = objectTexts.begin();
			for(; oi != objectTexts.end(); ++oi)
			{
				vector<int> *p = oi->second;
				delete p;
			}
			
		}

		if (!heapNode.empty())		
		{			
			while (!heapNode.empty())		
				//after each object is processed, the queue will be updated, therefore a node in the queue is always useful
			{
				RTreeNode *p = heapNode.front();
				pop_heap(heapNode.begin(), heapNode.end(), compareNode);	//the first element is moved to the last position				
				heapNode.pop_back();

				if( p->isNode)				//if the node is not an object, we read the next page.
				{	
					nextEntry = p->identifier;		
					hasNext = true;
					delete p;
					break;
				}

				double dist = p->minValue;
				KEYTYPE key = p->bitmap;
				group.insert(p->identifier);
				Cost += dist;
				keywordsBM = keywordsBM - key;
				
				if(keywordsBM == 0)
				{
					delete p;
					hasNext = false;
					break;
				}

				//update...
				
				int length = heapNode.size();
				for(int i=0; i< length; i++)
				{
					RTreeNode *t = heapNode[i];
					KEYTYPE tkey = t->bitmap;
					if( (tkey & key) == 0)		//the node shares no keywords with the current object
						continue;					

					KEYTYPE interS = tkey & keywordsBM;		//remove the words already covered
					if( interS == 0)			//the node's all keywords are covered
					{						
						delete t;
						heapNode[i] = heapNode[length-1];
						heapNode.pop_back();
						length--;
						i--;	//process the new object exchanged here in next loop!
						continue;
					}

					if(tkey != interS)
					{
						int pSize = MyTool::getNumOf1(tkey);
						t->bitmap = interS;
						int nSize = MyTool::getNumOf1(interS);
						t->minValue = t->minValue * pSize / nSize;
					}
				}				
				
				make_heap(heapNode.begin(), heapNode.end(), compareNode);				
				delete p;
			}		
		}
	
		else 
			hasNext = false;
	}
};//*/



class Problem1Baseline
{
	Query *Q;
	vector<int> keywords;
	double* Cost;
	set<KEYTYPE> **group;
	unsigned int keywordsBM;
	map<unsigned int, double> objectDist;

public:

	Problem1Baseline(Query *Q)
	{
		this->Q = Q;

		istringstream iss(Q->text);
		int wid; char c;
		while(iss>>wid)
		{
			keywords.push_back(wid);
			iss>>c;
		}

		keywordsBM = pow(2.0, (int)keywords.size());

		group = new set<KEYTYPE>*[keywordsBM];
		Cost = new double[keywordsBM];
		for(unsigned int i=0;i<keywordsBM;i++)
		{
			group[i] = NULL;
			Cost[i] = -1;
		}		
	}

	~Problem1Baseline()
	{
		for(unsigned int i=0;i<keywordsBM;i++)
			delete group[i];
		delete[] group;
		delete[] Cost;
	}

	double getCost()
	{
		return Cost[keywordsBM-1];
	}

	friend ostream& operator<<(ostream& out,Problem1Baseline & t)
	{
		out<<(t.Cost)[t.keywordsBM-1]<<":";
		set<KEYTYPE> * p = (t.group)[t.keywordsBM-1];
		set<KEYTYPE>::iterator iter = p->begin();
		for(; iter != p->end(); ++iter)
			out<<*iter<<" ";
		out<<endl;
		return out;
	}

	void ProcessLine(vector<int> &intersect, double dist, int oid)
	{
		set<unsigned int> subsets;
		GenerateSubSets(intersect, subsets);

		set<unsigned int>::iterator iterS;
		for(iterS = subsets.begin(); iterS != subsets.end(); ++iterS)
		{
			int bitmap = *iterS;
			double cost = Cost[bitmap];			
			if(cost > dist)
			{
				set<KEYTYPE> *p = group[bitmap];					
				p->clear();
				p->insert(oid);
				group[bitmap] = p;
				Cost[bitmap] = dist;				
			}
			else if(cost < 0)
			{
				set<KEYTYPE> *p = new set<KEYTYPE>();
				p->insert(oid);
				Cost[bitmap] = dist;
				group[bitmap] = p;
			}
		}
	}

	void PostProcess()
	{		
		for(unsigned int i = 1; i < keywordsBM; ++i)
		{			
			if(Cost[i] >= 0)
			{
				int oid = *(group[i]->begin());
				objectDist[oid] = Cost[i];
			}
		}

		for(unsigned int i=1;i<keywordsBM;i++)
		{
			double min = 10000;
			int bestSep = -1;
			for(unsigned int j=1;j<=i/2;j++)
			{
				if( (j & i) != j)		//j must be the subset of i
					continue;
				set<KEYTYPE> *p1 = group[j];
				set<KEYTYPE> *p2 = group[i-j];

				double d = Cost[j];
				set<KEYTYPE>::iterator s1, s2;
				for(s2 = p2->begin(); s2 != p2->end(); ++s2)
				{
					s1 = p1->find(*s2);
					if(s1 == p1->end())
					{
						d += objectDist[*s2];
					}
				}
				if(d == Cost[j])		//two subsets are contributed by same objects, do nothing
					continue;
				
				if(min > d)
				{
					min = d;
					bestSep = j;
				}
			}
			double cost = Cost[i];
			if(cost < 0)		//only if resMap[i] does not exist or it has larger value, we update it
			{
				Cost[i] = min;
				set<KEYTYPE> *p = new set<KEYTYPE>();
				p->insert(group[bestSep]->begin(), group[bestSep]->end());
				p->insert(group[i-bestSep]->begin(), group[i-bestSep]->end());
				group[i] = p;
			}
			else if( min < cost)
			{
				Cost[i] = min;
				set<KEYTYPE> *p = group[i];
				p->clear();
				p->insert(group[bestSep]->begin(), group[bestSep]->end());
				p->insert(group[i-bestSep]->begin(), group[i-bestSep]->end());
			}
		}
	}

	void BaseLine()
	{
		ifstream textF(textFile.c_str());
		ifstream locF(locFile.c_str());

		int count = 0;
		while ( !textF.eof())
		{
			string docLine;
			getline(textF, docLine);
			if(docLine == "")
				continue;
			string locLine;
			getline(locF, locLine);

			istringstream iss(docLine);			
			int oid, wid; char c;
			iss>>oid;
			vector<int> intersect;
			while(iss>>c>>wid)
			{
				unsigned int i;
				vector<int>::iterator ti = intersect.begin();
				for(; ti != intersect.end(); ++ti)
				{
					if(keywords[*ti] == wid)
						break;
				}
				if( ti != intersect.end())
					continue;

				for(i=0;i<keywords.size();i++)
				{
					if(keywords[i] == wid)
						break;
				}
				if(i < keywords.size())
					intersect.push_back(i);
			}
			
			if(!intersect.empty())
			{
				sort(intersect.begin(), intersect.end());
				double x, y;
				istringstream iss2(locLine);
				iss2>>oid>>c>>x>>c>>y;
				double dist = sqrt( (Q->x - x)*(Q->x - x) + (Q->y-y)*(Q->y-y) );
				ProcessLine(intersect, dist, count);
			}
			count++;
		}
		textF.close();
		locF.close();

		PostProcess();
	}
};



/* the dynamic programming method for the top-k results */
class Problem1Topk
{
private:
	Query *Q;                                                                                                                                                                                                                                                                                                                                                                                                                                                 
	vector<int> keywords;
	//double** Cost;
	//set<KEYTYPE> **group;
	typedef struct Bitmask 
	{
		double cost;
		set<KEYTYPE> group;
		friend bool operator<(const struct Bitmask &a, const struct Bitmask &b){
			return a.cost < b.cost;
		}
	}Topk;
	priority_queue<Topk>* pq;//pq[bitmask] : top-k results of bitmask
	unsigned int keywordsBM;//bitmask
	int ksize;//size of top-k
	vector<pair<int , Topk> >object;//mask,info of object

	/* keep the size of priority_queue not larger than ksize */
	void inline check(priority_queue<Topk>* cur){
		while(cur->size() > ksize)
			cur->pop();
	}

public:

	Problem1Topk(Query *Q, int ksize)
	{
		this->Q = Q;
		this->ksize = ksize;

		object.clear();

		istringstream iss(Q->text);
		int wid; char c;
		while(iss>>wid)
		{
			keywords.push_back(wid);
			iss>>c;
		}

		keywordsBM = 1 << keywords.size();

		pq = new priority_queue<struct Bitmask>[keywordsBM];
	}

	~Problem1Topk()
	{
		delete[] pq;
	}

	/*return a vector of top-k results*/
	priority_queue<struct Bitmask> getCost()
	{
		return pq[keywordsBM-1];
	}

	friend ostream& operator<<(ostream& out, Problem1Topk& t)
	{
		priority_queue<Topk> temp = (t.pq)[t.keywordsBM-1];
		int i = 0;
		while(!temp.empty()){
			Topk cur = temp.top();
			temp.pop();
			out<< "Top-"<< t.ksize - i << ": " << cur.cost <<":";
			set<KEYTYPE>::iterator iter = cur.group.begin();
			for(; iter != cur.group.end(); ++iter)
				out<<*iter<<" ";
			out<<endl;
			i++;
		}
		out<<endl;
		return out;
	}

	void ProcessLine(int bitmask, double dist, int oid)
	{
		Topk cur;
		cur.cost = dist;
		cur.group.insert(oid);
		
		//only consider top-k objects of each keywords combination(mask)
		//instead of all objects
		//and consider all keywords subsets of an object 
		for(int subset = bitmask; subset; subset = ( subset - 1 ) & bitmask){
			if(pq[subset].size() < ksize || pq[subset].top().cost > cur.cost){
				pq[subset].push(cur);
				check(&pq[subset]);
			}
		}
		//object.push_back(make_pair<int , Topk>(bitmask, cur) );
	}

	void Process()
	{	
		//here use a set because an object may occur in different subsets
		set<KEYTYPE>repeat;
		for(int i = keywordsBM - 1; i >=0 ; i--){
			priority_queue<Topk> &temp = pq[i];
			//printf("%d\n",temp.size());
			while(!temp.empty()){
				Topk cur = temp.top();
				temp.pop();
				if(repeat.count(*cur.group.begin()) > 0){
					continue;
				}
				repeat.insert(*cur.group.begin());
				object.push_back(make_pair<int, Topk>(i, cur) );
			}
		}

		//empty set initial
		Topk empty;
		empty.cost = 0.0;
		pq[0].push(empty);
		for(unsigned int j = 0; j < object.size(); j++){
			int mask = object[j].first;
			/*enumerate bitmask from big to small in case repeated object added to the group*/
			for(int bitmask_cur = keywordsBM - 1; bitmask_cur >= 0; bitmask_cur--){
				priority_queue<Topk> temp = pq[bitmask_cur];
				while(!temp.empty()){
					Topk update = temp.top();
					temp.pop();
					int bitmask_next = bitmask_cur | mask;

					update.cost  += object[j].second.cost;
					update.group.insert(*object[j].second.group.begin());

					if(pq[bitmask_next].size() < ksize || pq[bitmask_next].top().cost > update.cost){
						pq[bitmask_next].push(update);
						check(&pq[bitmask_next]);
					}
				}
			}
		}
	}

	void BaseLine()
	{
		ifstream textF(textFile.c_str());
		ifstream locF(locFile.c_str());

		int count = 0;
		while ( !textF.eof())
		{
			string docLine;
			getline(textF, docLine);
			if(docLine == "")
				continue;
			string locLine;
			getline(locF, locLine);

			istringstream iss(docLine);			
			int oid, wid; char c;
			iss>>oid;
			//vector<int> intersect;
			int bitmask = 0;
			while(iss>>c>>wid)
			{
				unsigned int i;
				for(i=0;i<keywords.size();i++)
				{
					if(keywords[i] == wid){
						bitmask |= 1<<i;
						break;
					}
				}
			}
			
			if(bitmask)
			{
				double x, y;
				istringstream iss2(locLine);
				iss2>>oid>>c>>x>>c>>y;
				double dist = sqrt( (Q->x - x)*(Q->x - x) + (Q->y-y)*(Q->y-y) );
				ProcessLine(bitmask, dist, count);
			}
			count++;
		}
		textF.close();
		locF.close();

		Process();
	}
};


/* the dynamic programming method */
class Problem1DP
{
private:
	Query *Q;                                                                                                                                                                                                                                                                                                                                                                                                                                                 
	vector<int> keywords;
	unsigned int keywordsBM;//bitmask
	double* Cost;
	set<KEYTYPE> *group;
	vector<pair<int , int> >object;//mask, id
public:
	Problem1DP(Query *Q)
	{
		this->Q = Q;

		istringstream iss(Q->text);
		int wid; 
		char c;
		while(iss>>wid)
		{
			keywords.push_back(wid);
			iss>>c;
		}

		keywordsBM = 1<<keywords.size();
		group = new set<KEYTYPE>[keywordsBM];
		Cost  = new double[keywordsBM];
		for(unsigned int i=0;i<keywordsBM;i++)
		{
			Cost[i] = -1.0;
		}	
	}
	~Problem1DP()
	{
		delete[] Cost;
		delete[] group;
	}

	void ProcessLine(int bitmask, double dist, int oid)
	{
		if(Cost[bitmask] < 0 || Cost[bitmask] > dist){
			Cost[bitmask] = dist;
			group[bitmask].clear();
			group[bitmask].insert(oid);
		}
	}

	void BaseLine()
	{
		ifstream textF(textFile.c_str());
		ifstream locF(locFile.c_str());

		int count = 0;
		while ( !textF.eof())
		{
			string docLine;
			getline(textF, docLine);
			if(docLine == "")
				continue;
			string locLine;
			getline(locF, locLine);

			istringstream iss(docLine);			
			int oid, wid; char c;
			iss>>oid;
			//vector<int> intersect;
			int bitmask = 0;
			while(iss>>c>>wid)
			{
				unsigned int i;
				for(i=0;i<keywords.size();i++)
				{
					if(keywords[i] == wid){
						bitmask |= 1<<i;
						break;
					}
				}
			}
			
			if(bitmask)
			{
				double x, y;
				istringstream iss2(locLine);
				iss2>>oid>>c>>x>>c>>y;
				double dist = sqrt( (Q->x - x)*(Q->x - x) + (Q->y-y)*(Q->y-y) );
				ProcessLine(bitmask, dist, count);
			}
			count++;
		}
		textF.close();
		locF.close();

		PostProcess();
	}

	double getCost()
	{
		return Cost[keywordsBM-1];
	}

	friend ostream& operator<<(ostream& out, Problem1DP & t)
	{
		out<<(t.Cost)[t.keywordsBM-1]<<":";
		set<KEYTYPE> p = (t.group)[t.keywordsBM-1];
		set<KEYTYPE>::iterator iter = p.begin();
		for(; iter != p.end(); ++iter)
			out<<*iter<<" ";
		out<<endl;
		return out;
	}

	void PostProcess()
	{
		for(unsigned int i = 1; i < keywordsBM; ++i)
		{			
			if(Cost[i] >= 0)
			{
				int oid = *(group[i].begin());
				object.push_back(make_pair(i, oid));
			}
		}
		Cost[0] = 0.0;//empty set
		for(unsigned int s = 0; s < keywordsBM; ++s)
		{
			if(Cost[s] < 0)
				continue;
			for(unsigned int i = 0; i < object.size(); ++i){
				int new_mask = s | object[i].first;
				double new_cost = Cost[s] + Cost[object[i].first];
				if(Cost[new_mask] < 0 || Cost[new_mask] > new_cost){
					Cost[new_mask]  = new_cost;
					group[new_mask] = group[s];

					set<KEYTYPE>::iterator it=group[object[i].first].begin();
					for(;it!=group[object[i].first].end();it++){
						group[new_mask].insert(*it);
					}
					//group[new_mask].insert(object[i].second);
				}
			}
		}
	}
};

/*topk + index*/
class Problem1IBRTreeTopk : public SpatialIndex::IQueryStrategy
{
private:
	priority_queue<RTreeNode *, deque<RTreeNode *>, NodeValueLess<RTreeNode> > queueNode;	
	Query *Q;
	vector<int> keywords;
	int nodeNum;
	typedef struct Bitmask 
	{
		double cost;
		set<KEYTYPE> group;
		friend bool operator<(const struct Bitmask &a, const struct Bitmask &b){
			return a.cost < b.cost;
		}
	}Topk;
	priority_queue<Topk>* marked; //marked[bitmask] : top-k results of bitmask (marked)
	priority_queue<Topk>* valued; //value[bitmask]  : top-k results of bitmask (valued)

	unsigned int keywordsBM;  //bitmask
	int ksize;//size of top-k

	/* keep the size of priority_queue not larger than ksize */
	void inline check(int bitmap){
		while(marked[bitmap].size() + valued[bitmap].size() > ksize && !valued[bitmap].empty()){
			valued[bitmap].pop();
		}
		while(marked[bitmap].size() > ksize){
			marked[bitmap].pop();
		}
	}
public:
	Problem1IBRTreeTopk(Query *Q, int ksize, int nodeNum)
	{
		this->Q = Q;
		this->nodeNum = nodeNum;	
		this->ksize = ksize;

		istringstream iss(Q->text);
		int wid; char c;
		while(iss>>wid)
		{
			keywords.push_back(wid);
			iss>>c;
		}

		keywordsBM = 1<<keywords.size();
		marked = new priority_queue<Topk>[keywordsBM];
		valued = new priority_queue<Topk>[keywordsBM];
	}
	~Problem1IBRTreeTopk()
	{
		for(unsigned int i = 0; i < keywordsBM; i++){
			while(!marked[i].empty())
				marked[i].pop();
			while(!valued[i].empty())
				valued[i].pop();
		}
		delete[] marked;
		delete[] valued;
		while (!queueNode.empty())		
		{
			RTreeNode *p = queueNode.top();
			queueNode.pop();
			delete p;	
		}
	}
	friend ostream& operator<<(ostream& out, Problem1IBRTreeTopk& t)
	{
		while(!(t.valued)[t.keywordsBM-1].empty()){
			(t.marked)[t.keywordsBM-1].push( (t.valued)[t.keywordsBM-1].top() );
			(t.valued)[t.keywordsBM-1].pop();
		}
		priority_queue<Topk> temp = (t.marked)[t.keywordsBM-1];
		int i = temp.size();
		while(!temp.empty()){
			Topk cur = temp.top();
			temp.pop();
			out<< "Top-"<< i << ": " << cur.cost <<":";
			set<KEYTYPE>::iterator iter = cur.group.begin();
			for(; iter != cur.group.end(); ++iter)
				out<<*iter<<" ";
			out<<endl;
			i--;
		}
		out<<endl;
		return out;
	}
	void getNextEntry(const IEntry& entry, id_type& nextEntry, bool& hasNext)
	{
		const INode* n = dynamic_cast<const INode*>(&entry);
		if (n != 0)
		{
			int pid = n->getIdentifier();
			string btFile = btreeFolder + MyTool::IntToString(pid);
			char *btfname = new char[btFile.size()+1];
			memcpy(btfname, btFile.c_str(), btFile.size());		
			btfname[btFile.size()] = '\0';
			BTree *bt = new BTree(btfname, 0);	
			
			map<int, vector<int>*> objectTexts;		//the text description of an object
			set<int> indexID;						//the id of child nodes which contains query keywords				
			map<int, vector<int>*>::iterator iterMap;
			for(unsigned int k=0;k<keywords.size();k++)
			{
				int wordID = keywords[k];
				int sdfasd = DIMENSION;
				unsigned char *data = new unsigned char[DIMENSION];
				bool flag = bt->search(wordID, &data);
				if(flag)
				{			
					int i;
					for(i=0;i<DIMENSION;i++)
					{
						if(data[i] > 0)							
						{
							unsigned char mask = 1;
							for(int j=0;j<8;j++)
							{
								if((data[i] & mask) > 0)
								{
									int index = i*8+j;
									indexID.insert(index);
									iterMap = objectTexts.find(index);
									if(iterMap ==  objectTexts.end())
									{
										vector<int> *p = new vector<int>();		
										p->push_back(k);		//the index of the word in keywords, not the real word id!
										objectTexts[index] = p;
									}
									else
									{
										vector<int> *p = iterMap->second;
										p->push_back(k);
									}
								}
								mask = mask << 1;
							}
						}
					}
				}
				delete data;
			}
			delete bt;
			delete btfname;

			set<int>::iterator si = indexID.begin();
			for(;si != indexID.end(); ++si)	
			{
				uint32_t cChild = *si;
				int cid = n->getChildIdentifier(cChild);
				
				IShape *out;
				n->getChildShape(cChild, &out);
				Region* pr = dynamic_cast<Region *>(out);	

				double dx = Q->x - pr->m_pHigh[0];
				double dy = Q->y - pr->m_pHigh[1];

				KEYTYPE keyValue = MyTool::ConvertToInt(objectTexts[cChild]);
				if(marked[keyValue].size() == ksize)		//the keywords set of this node has know lowest cost
				{
					delete pr;
					continue;
				}

				double dist;
				RTreeNode *rtp = new RTreeNode;

				if(n->isLeaf())
				{
					dist = sqrt(dx * dx + dy * dy);
					rtp->isNode = false;
				}
				if(n->isIndex())
				{
					double coor[2];
					coor[0] = Q->x; coor[1] = Q->y;
					Point pt(coor, 2);

					dist = MyTool::ComputeMinPossible(pr, &pt);
					rtp->pr = pr;
					rtp->isNode = true;
				}
				
				rtp->identifier = n->getChildIdentifier(cChild);
				rtp->minValue = dist;
				rtp->bitmap = keyValue;
				queueNode.push(rtp);
			}	

			map<int, vector<int>*>::iterator oi = objectTexts.begin();
			for(; oi != objectTexts.end(); ++oi)
			{
				vector<int> *p = oi->second;
				delete p;
			}
		}
		
			while (!queueNode.empty())
			{
				RTreeNode *p = queueNode.top();
				queueNode.pop();
				if( p->isNode )		//if the node is not an object, we read the next page.
				{
					KEYTYPE keyValue = p->bitmap;
					if(marked[keyValue].size() == ksize)
					{
						delete p;
						continue;
					}
					else
					{
						nextEntry = p->identifier;
						hasNext = true;
						delete p;
						return;
					}
				}

				double dist = p->minValue;

				// utilize dist to move some subsets to marked set. because the lowest cost is known now
				for(unsigned int i = 0; i < keywordsBM; i++){
					if(!valued[i].empty()){
						priority_queue<Topk> temp;
						while(!valued[i].empty()){
							Topk cur = valued[i].top();
							valued[i].pop();
							if(cur.cost <= dist){
								marked[i].push(cur);
							}
							else{
								temp.push(cur);
							}
						}
						valued[i] = temp;
					}
				}

				int oid = p->identifier;
				KEYTYPE bitmap = p->bitmap;
				if(marked[bitmap].size() < ksize)
				{
					//combine with other group
					for(int i = keywordsBM - 1; i >= 1; i--){
						KEYTYPE unionS = i | bitmap;
						
						//if(unionS == i || unionS == bitmap)
						//	continue;

						priority_queue<Topk> temp;
						for(int j = 0; j < 2; j++){
							temp = j ? marked[i] : valued[i];
							while(!temp.empty()){
								Topk cur = temp.top();
								temp.pop();
								cur.cost += dist;
								cur.group.insert(oid);
								//updatepq(&valued[unionS], cur);
								if(marked[unionS].size() + valued[unionS].size() < ksize ||
									(!valued[unionS].empty() && valued[unionS].top().cost > cur.cost ) ){
									valued[unionS].push(cur);
									check(unionS);
								}
							}
						}
					}

					//enumerate all subsets of bitmap
					//for(unsigned int subset = bitmap; subset; subset = (subset-1)&bitmap)
					unsigned int subset = bitmap;
					{
						Topk cur;
						cur.cost = dist;
						cur.group.insert(oid);
						//updatepq(&marked[subset], cur);
						if(marked[subset].size() < ksize || cur.cost < marked[subset].top().cost){
							marked[subset].push(cur);
							check(subset);
						}
					}
				}
				delete p;
				if(marked[keywordsBM-1].size() == ksize)
				{
					hasNext = false;
					break;
				}
			}
			hasNext = false;
	}
};

/* the dynamic programming method with index*/
class Problem1IBRTree : public SpatialIndex::IQueryStrategy
{
private:	
	priority_queue<RTreeNode *, deque<RTreeNode *>, NodeValueLess<RTreeNode> > queueNode;	
	Query *Q;
	int nodeNum;	
	vector<int> keywords;
	set<KEYTYPE> **group;
	double *Cost;
	KEYTYPE keywordsBM;	
	set<KEYTYPE> markedSet;
	set<KEYTYPE> valuedSet;
	bool *mark;
				
public:
	
	Problem1IBRTree(Query *Q, int nodeNum)
	{
		this->Q = Q;
		this->nodeNum = nodeNum;		

		istringstream iss(Q->text);
		int wid; char c;
		while(iss>>wid)
		{
			keywords.push_back(wid);
			iss>>c;
		}

		keywordsBM = pow(2.0, (int)keywords.size());

		group = new set<KEYTYPE>*[keywordsBM];
		Cost = new double[keywordsBM];		
		mark = new bool[keywordsBM];
		for(KEYTYPE i=0;i<keywordsBM;i++)
		{
			group[i] = NULL;
			Cost[i] = -1;			
			mark[i] = false;
		}	
	}

	~Problem1IBRTree()
	{
		for(KEYTYPE i=0;i<keywordsBM;i++)
			delete group[i];
		delete[] group;
		delete Cost;

		while (!queueNode.empty())		
		{
			RTreeNode *p = queueNode.top();
			queueNode.pop();
			delete p;			
		}
	}

	double getCost()
	{
		return Cost[keywordsBM-1];
	}

	friend ostream& operator<<(ostream& out,Problem1IBRTree & t)
	{
		out<<(t.Cost)[t.keywordsBM-1]<<":";
		set<KEYTYPE> * p = (t.group)[t.keywordsBM-1];
		set<KEYTYPE>::iterator iter = p->begin();
		for(; iter != p->end(); ++iter)
			out<<*iter<<" ";
		out<<endl;
		return out;
	}

	void getNextEntry(const IEntry& entry, id_type& nextEntry, bool& hasNext)
	{	
		const INode* n = dynamic_cast<const INode*>(&entry);

		if (n != 0)
		{
			int pid = n->getIdentifier();
			string btFile = btreeFolder + MyTool::IntToString(pid);
			char *btfname = new char[btFile.size()+1];
			memcpy(btfname, btFile.c_str(), btFile.size());		
			btfname[btFile.size()] = '\0';
			BTree *bt = new BTree(btfname, 0);	
			
			map<int, vector<int>*> objectTexts;		//the text description of an object
			set<int> indexID;						//the id of child nodes which contains query keywords				
			map<int, vector<int>*>::iterator iterMap;
			for(unsigned int k=0;k<keywords.size();k++)
			{
				int wordID = keywords[k];
				int sdfasd = DIMENSION;
				unsigned char *data = new unsigned char[DIMENSION];
				bool flag = bt->search(wordID, &data);
				if(flag)
				{			
					int i;
					for(i=0;i<DIMENSION;i++)
					{
						if(data[i] > 0)							
						{
							unsigned char mask = 1;
							for(int j=0;j<8;j++)
							{
								if((data[i] & mask) > 0)
								{
									int index = i*8+j;
									indexID.insert(index);
									iterMap = objectTexts.find(index);
									if(iterMap ==  objectTexts.end())
									{
										vector<int> *p = new vector<int>();		
										p->push_back(k);		//the index of the word in keywords, not the real word id!
										objectTexts[index] = p;
									}
									else
									{
										vector<int> *p = iterMap->second;
										p->push_back(k);
									}
								}
								mask = mask << 1;
							}
						}
					}
				}
				delete data;
			}
			delete bt;
			delete btfname;

			set<int>::iterator si = indexID.begin();
			for(;si != indexID.end(); ++si)	
			{
				uint32_t cChild = *si;
				int cid = n->getChildIdentifier(cChild);
				
				IShape *out;
				n->getChildShape(cChild, &out);
				Region* pr = dynamic_cast<Region *>(out);	

				double dx = Q->x - pr->m_pHigh[0];
				double dy = Q->y - pr->m_pHigh[1];											

				KEYTYPE keyValue = MyTool::ConvertToInt(objectTexts[cChild]);
				if(mark[keyValue])		//the keywords set of this node has know lowest cost
				{
					delete pr;
					continue;
				}

				double dist;
				RTreeNode *rtp = new RTreeNode;

				if(n->isLeaf())
				{
					dist = sqrt(dx * dx + dy * dy);
					rtp->isNode = false;
				}
				if(n->isIndex())
				{
					double coor[2];
					coor[0] = Q->x; coor[1] = Q->y;
					Point pt(coor, 2);

					dist = MyTool::ComputeMinPossible(pr, &pt);
					rtp->pr = pr;
					rtp->isNode = true;
				}
				
				rtp->identifier = n->getChildIdentifier(cChild);
				rtp->minValue = dist;
				rtp->bitmap = keyValue;
				queueNode.push(rtp);
			}	

			map<int, vector<int>*>::iterator oi = objectTexts.begin();
			for(; oi != objectTexts.end(); ++oi)
			{
				vector<int> *p = oi->second;
				delete p;
			}
		}

		if (!queueNode.empty())		
		{			
			while (!queueNode.empty())
			{
				RTreeNode *p = queueNode.top();
				queueNode.pop();
				if( p->isNode )		//if the node is not an object, we read the next page.
				{
					KEYTYPE keyValue = p->bitmap;
					if(mark[keyValue])
					{
						delete p;						
						continue;
					}
					else
					{
						nextEntry = p->identifier;
						hasNext = true;
						delete p;
						break;
					}
				}

				double dist = p->minValue;

				set<KEYTYPE>::iterator si = valuedSet.begin();	
							// utilize dist to move some subsets to marked set. because the lowest cost is known now
				set<KEYTYPE> moved;
				for(;si != valuedSet.end(); ++si)
				{
					int bitmap = *si;
					if(Cost[bitmap] <= dist)
					{
						moved.insert(bitmap);
						markedSet.insert(bitmap);
						mark[bitmap] = true;
					}
				}
				for(si = moved.begin(); si != moved.end(); ++si)
					valuedSet.erase(*si);
				
				int oid = p->identifier;
				
				KEYTYPE bitmap = p->bitmap;
				if(!mark[bitmap])
				{
					set<KEYTYPE> subsets;
					set<KEYTYPE> tempSet;
					vector<int> *wids = MyTool::ConvertToSet(bitmap);
					GenerateSubSets(*wids, subsets);
					delete wids;
					for(si = subsets.begin(); si != subsets.end(); ++si)
					{
						int bitmap = *si;
						if(mark[bitmap])		//this subset already has lowest cost
							continue;

						if(Cost[bitmap] >= 0)
						{
							valuedSet.erase(bitmap);
							set<KEYTYPE> *g = group[bitmap];
							g->clear(); g->insert(oid);
						}
						else
						{	
							set<KEYTYPE> *g = new set<KEYTYPE>();
							g->insert(oid);
							group[bitmap] = g;
						}
						Cost[bitmap] = dist;
						mark[bitmap] = true;
						tempSet.insert(bitmap);
						markedSet.insert(bitmap);
					}

					for(si = tempSet.begin(); si != tempSet.end(); ++si)
					{
						KEYTYPE i = *si;
						for(KEYTYPE j=1;j<keywordsBM;j++)
						{							
							if(Cost[j] < 0)
								continue;

							KEYTYPE unionS = i | j;
							if( unionS == i || unionS == j)
								continue;

							double D = dist + Cost[j];
							if(Cost[unionS] < 0)			//the new combination does not have a value
							{
								Cost[unionS] = D;
								set<KEYTYPE> *g = new set<KEYTYPE>();
								g->insert(group[j]->begin(), group[j]->end());
								g->insert(oid);
								group[unionS] = g;
								valuedSet.insert(unionS);
							}
							else if( Cost[unionS] > D)		//the previous cost is larger than the current one
							{
								Cost[unionS] = D;
								set<KEYTYPE> *g = group[unionS];
								g->clear();
								g->insert(group[j]->begin(), group[j]->end());
								g->insert(oid);
							}
						}
					}
				}
				delete p;
				if(mark[keywordsBM-1])
				{
					hasNext = false;
					break;
				}
			}			
		}
	
		else 
			hasNext = false;
	}
	
};

#endif