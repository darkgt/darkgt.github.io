#ifndef _TOPKBASE_
#define _TOPKBASE_

#include <iostream>
#include <SpatialIndex.h>
#include <map>
#include <set>
#include <vector>
#include <cmath>
#include <queue>
#include "Tool.h"
#include "data.h"
#include "btree.h"
#include "IBRtree.h"
#include "SearchIBRTree.h"

using namespace std;

extern string textFile;
extern string locFile;
extern string invertedFile;
extern string subdocFolder;
extern string btreeFolder;
extern string treeFile;

extern int numOfEntry;
extern double alpha;

class TopkBase: public SpatialIndex::IQueryStrategy
{
private:	
	priority_queue<RTreeNode *, deque<RTreeNode *>, NodeValueLess<RTreeNode> > queueNode;	
	Query *Q;
	int nodeNum;
	vector<int> keywords;
	KEYTYPE keywordsBM;
	vector<Object> group;
	double distLowerbound;//The distance from object to query should larger than this value
				
public:
	TopkBase(Query *Q, int nodeNum, KEYTYPE keywordsBM = 0, double distLowerbound = 0.0)
	{
		this->Q = Q;
		this->nodeNum = nodeNum;
		this->distLowerbound = distLowerbound;

		istringstream iss(Q->text);
		int wid; char c;
		while(iss>>wid)
		{
			keywords.push_back(wid);
			iss>>c;
		}

		this->keywordsBM = keywordsBM;
	}

	~TopkBase()
	{
		while( !queueNode.empty())
		{
			RTreeNode *p = queueNode.top();
			queueNode.pop();
			delete p;
		}
	}

	bool isvalid(){
		int mask = 0;
		for(unsigned i = 0;i < group.size();i++){
			mask |= group[i].mask;
		}
		return keywordsBM == (mask & keywordsBM);
	}

	vector<Object> getGroup()
	{
		return group;
	}

	void getNextEntry(const IEntry& entry, id_type& nextEntry, bool& hasNext)
	{	
		const INode* n = dynamic_cast<const INode*>(&entry);
		if (n != 0)
		{
			int pid = n->getIdentifier();
			string btFile = btreeFolder + MyTool::IntToString(pid);
			char *btfname = new char[btFile.size()+1];
			memcpy(btfname, btFile.c_str(), btFile.size());		
			btfname[btFile.size()] = '\0';
			BTree *bt = new BTree(btfname, 0);	
			
			map<int, vector<int>*> objectTexts;		//the text description of an object
			set<int> indexID;						//the id of child nodes which contains query keywords				
			map<int, vector<int>*>::iterator iterMap;
			for(unsigned int k=0;k<keywords.size();k++)
			{
				int wordID = keywords[k];
				VECTYPE *data = new VECTYPE[DIMENSION];
				bool flag = bt->search(wordID, &data);
				if(flag)
				{					
					for(int i=0;i<DIMENSION;i++)
					{
						if(data[i] > 0)							
						{
							unsigned char mask = 1;
							for(int j=0;j<8;j++)
							{
								if((data[i] & mask) > 0)
								{
									int index = i*8+j;
									indexID.insert(index);
									iterMap = objectTexts.find(index);
									if(iterMap ==  objectTexts.end())
									{
										vector<int> *p = new vector<int>();		
										p->push_back(k);
										objectTexts[index] = p;
									}
									else
									{
										vector<int> *p = iterMap->second;
										p->push_back(k);
									}
								}
								mask = mask << 1;
							}
						}
					}
				}
				delete data;
			}
			delete bt;
			delete btfname;

			set<int>::iterator si = indexID.begin();
			for(;si != indexID.end(); ++si)	
			{
				uint32_t cChild = *si;
				int cid = n->getChildIdentifier(cChild);
				
				IShape *out;
				n->getChildShape(cChild, &out);
				Region* pr = dynamic_cast<Region *>(out);	

				double dx = Q->x - pr->m_pHigh[0];
				double dy = Q->y - pr->m_pHigh[1];

				int key = MyTool::ConvertToInt(objectTexts[cChild]);
				if( (key & keywordsBM) == 0)
					continue;

				double dist;
				RTreeNode *rtp = new RTreeNode;

				if(n->isLeaf())
				{
					dist = sqrt(dx * dx + dy * dy);
					if(dist < distLowerbound)
						continue;
					rtp->isNode = false;
				}
				if(n->isIndex())
				{
					double coor[2];
					coor[0] = Q->x; coor[1] = Q->y;
					Point pt(coor, 2);

					dist = MyTool::ComputeMinPossible(pr, &pt);
					//if( MyTool::ComputeMaxPossible(pr, &pt) < distLowerbound)
						//continue;
					rtp->isNode = true;
				}
				
				rtp->identifier = n->getChildIdentifier(cChild);
				rtp->minValue = dist;
				rtp->bitmap = MyTool::ConvertToInt(objectTexts[cChild]);
				rtp->pr = pr;

				queueNode.push(rtp);
			}
			map<int, vector<int>*>::iterator oi = objectTexts.begin();
			for(; oi != objectTexts.end(); ++oi)
			{
				vector<int> *p = oi->second;
				delete p;
			}
		}

		if (!queueNode.empty())
		{			
			while (!queueNode.empty())
			{
				RTreeNode *p = queueNode.top();
				queueNode.pop();

				if( p->isNode )		//if the node is not an object, we read the next page.
				{	
					KEYTYPE keyValue = p->bitmap;
					if( (keyValue & keywordsBM) > 0)
					{
						nextEntry = p->identifier;
						hasNext = true;
						delete p;
						break;
					}
				}
				else
				{
					KEYTYPE key = p->bitmap;
					int interS = key & keywordsBM;
					if(interS > 0)		//contains some keywords that have not been covered
					{
						Object append;
						append.id = p->identifier;
						append.mask = key;
						append.x = p->pr->m_pLow[0];
						append.y = p->pr->m_pLow[1];
						group.push_back(append);
						//group.push_back(p->identifier);
						keywordsBM = keywordsBM - interS;
						if(keywordsBM == 0)
						{
							hasNext = false;
							delete p;
							break;
						}
					}
				}
				delete p;
			}
		}
	
		else 
			hasNext = false;
	}
};

class TopkAppr{
protected:
	vector< vector<Object> >TopkResult;
	queue< vector<Object> >GroupQueue;

	Query *Q;
	int nodeNum;
	vector<int> keywords;
	int ksize;
	KEYTYPE keywordsBM;
	IBRTree *irtree;
	set<set<int> >repeatGroup;
public:
	TopkAppr(){}
	~TopkAppr(){}

	void Test(Query *Q, int nodeNum, int k, IBRTree *irtree)
	{
		this->Q = Q;
		this->nodeNum = nodeNum;
		this->irtree = irtree;
		ksize = k;

		istringstream iss(Q->text);
		int wid; char c;
		while(iss>>wid)
		{
			keywords.push_back(wid);
			iss>>c;
		}
		this->keywordsBM = (1 << keywords.size()) - 1;
		Process();
	}

	double Querydist(const Object &a){
		return sqrt( (a.x-Q->x) * (a.x-Q->x) + (a.y-Q->y) * (a.y-Q->y) );
	}

	double Objdist(const Object &a,const Object &b){
		return sqrt( (a.x-b.x)*(a.x-b.x) + (a.y-b.y)*(a.y-b.y) );
	}

	bool isRepeat(vector<Object>group){
		set<int>id;
		for(unsigned i =0 ;i < group.size();i++){
			id.insert(group[i].id);
		}
		if(repeatGroup.count(id) > 0)
			return true;
		else{
			repeatGroup.insert(id);
			return false;
		}
	}

	friend ostream& operator<<(ostream& out,TopkAppr & t)    
	{
		for(unsigned i = 0; i < t.TopkResult.size(); i++){
			out<< "Top-"<< i+1 << ": " << t.getCost(t.TopkResult[i]) <<":";
			for(unsigned j = 0; j < t.TopkResult[i].size(); j++){
				out<< t.TopkResult[i][j].id <<" ";
			}
			out<<endl;
		}
		out<<endl;
		return out;
	}

	bool generateGroup(const vector<Object>&curgroup, int exceptIndex, vector<Object>& newgroup){
		int mask = 0;
		for(unsigned i = 0; i < curgroup.size(); i++)
			if(i != exceptIndex)
				mask |= curgroup[i].mask;

		if(mask != keywordsBM){
			double eps = 1e-9;//very small value in case of accurcy problem
			TopkBase topkb(Q, nodeNum, keywordsBM ^ mask, Querydist(curgroup[exceptIndex]) + eps);
			irtree->GetTree()->queryStrategy(topkb);
			newgroup = topkb.getGroup();
			if(!topkb.isvalid())
				return false;
		}
		else{
			//cout<<"New result"<<endl;
			newgroup.clear();
		}

		for(unsigned i = 0; i < curgroup.size(); i++)
			if(i != exceptIndex)
				newgroup.push_back(curgroup[i]);

		return true;
	}

	virtual double getCost(vector<Object>group){
		return 0.0;
	}

	void Process(){
		//Initialize the queue
		TopkBase topkb(Q, nodeNum, keywordsBM, 0.0);
		irtree->GetTree()->queryStrategy(topkb);

		vector<Object>group = topkb.getGroup();
		GroupQueue.push(group);
		isRepeat(group);

		while(!GroupQueue.empty() && TopkResult.size() < ksize){
			vector<Object>curgroup = GroupQueue.front();
			TopkResult.push_back(curgroup);
			GroupQueue.pop();
			for(unsigned i = 0; i < curgroup.size(); i++){
				vector<Object>candidateGroup;
				if(!generateGroup(curgroup, i, candidateGroup))
					continue;
				if(!isRepeat(candidateGroup))
					GroupQueue.push(candidateGroup);
			}
		}
		vector< pair<double, vector<Object> > >TopkRank;
		for(unsigned i = 0; i < TopkResult.size(); i++)
			TopkRank.push_back( make_pair(getCost(TopkResult[i]), TopkResult[i]) );
		sort(TopkRank.begin(), TopkRank.end());

		TopkResult.clear();
		for(unsigned i = 0; i < TopkRank.size() ; i++)
			TopkResult.push_back(TopkRank[i].second);	
	}

	vector< vector<Object> > getResult(){
		return TopkResult;
	}
};

class MaxmaxTopkAppr: public TopkAppr{
public:
	MaxmaxTopkAppr(Query *Q, int nodeNum, int k)
	{
		this->Q = Q;
		this->nodeNum = nodeNum;
		ksize = k;

		istringstream iss(Q->text);
		int wid; char c;
		while(iss>>wid)
		{
			keywords.push_back(wid);
			iss>>c;
		}
		this->keywordsBM = (1 << keywords.size()) - 1;
		Process();
	}

	MaxmaxTopkAppr(){}
	~MaxmaxTopkAppr(){}
	
	double getCost(vector<Object>group){
		double furthest = 0.0, pairDist = 0.0;
		int checkmask = 0;
		for(unsigned i = 0; i < group.size(); i++){
			for(unsigned j = i+1; j < group.size(); j++){
				pairDist = max(pairDist, Objdist(group[i], group[j]));
			}
			furthest = max(furthest, Querydist(group[i]));
			checkmask |= group[i].mask;
		}
		//cerr<<"[DEBUG] checkmask = "<<checkmask<<endl;
		return furthest * alpha + pairDist * (1 - alpha);
	}
};

class MinmaxTopkAppr: public TopkAppr{
public:
	MinmaxTopkAppr(Query *Q, int nodeNum, int k)
	{
		this->Q = Q;
		this->nodeNum = nodeNum;
		ksize = k;

		istringstream iss(Q->text);
		int wid; char c;
		while(iss>>wid)
		{
			keywords.push_back(wid);
			iss>>c;
		}
		this->keywordsBM = (1 << keywords.size()) - 1;
		Process();
	}
	MinmaxTopkAppr(){}
	~MinmaxTopkAppr(){}
	
	double getCost(vector<Object>group){
		double nearest = 1e55, pairDist = 0.0;
		for(unsigned i = 0; i < group.size(); i++){
			for(unsigned j = i+1; j < group.size(); j++){
				pairDist = max(pairDist, Objdist(group[i], group[j]));
			}
			nearest = min(nearest, Querydist(group[i]));
		}
		return nearest * alpha + pairDist * (1 - alpha);
	}
};

#endif