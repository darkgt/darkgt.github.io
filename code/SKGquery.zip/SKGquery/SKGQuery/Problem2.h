#ifndef _PROBLEM2_
#define _PROBLEM2_

#include <iostream>
#include <SpatialIndex.h>
#include <map>
#include <set>
#include <vector>
#include <cmath>
#include "Tool.h"
#include "data.h"
#include "btree.h"
#include "IBRtree.h"
#include "SearchIBRTree.h"
#include "topkbase.h"

using namespace std;

extern string textFile;
extern string locFile;
extern string invertedFile;
extern string subdocFolder;
extern string btreeFolder;
extern string treeFile;

extern int numOfEntry;
extern double alpha;

#define DEBUG
#define TIMEOUT

class Problem2Appr1 : public SpatialIndex::IQueryStrategy
{
private:	
	priority_queue<RTreeNode *, deque<RTreeNode *>, NodeValueLess<RTreeNode> > queueNode;	
	Query *Q;
	int nodeNum;
	vector<int> keywords;
	KEYTYPE keywordsBM;	
	vector<int> group;
	double cost;
	map<int, Point> objLoc;
	bool usedInAPP2;
				
public:

	Query furthestObj;		//this structure is used for the second approximate algorithm
	
	Problem2Appr1(Query *Q, int nodeNum, bool usedInAPP2=false)
	{
		this->Q = Q;
		this->nodeNum = nodeNum;		

		istringstream iss(Q->text);
		int wid; char c;
		while(iss>>wid)
		{
			keywords.push_back(wid);
			iss>>c;
		}

		keywordsBM = pow(2.0, (int)keywords.size())-1;
		cost = 0;
		this->usedInAPP2 = usedInAPP2;
	}

	~Problem2Appr1()
	{
		while( !queueNode.empty())
		{
			RTreeNode *p = queueNode.top();
			queueNode.pop();
			delete p;
		}
	}

	friend ostream& operator<<(ostream& out,Problem2Appr1 & t)    
	{
		out<<t.getCost()<<":";
		vector<int>::iterator iter = t.group.begin();
		for(; iter != t.group.end(); ++iter)
			out<<*iter<<" ";
		out<<endl;
		return out;
	}

	void setQuery(Query *Q)
	{
		this->Q = Q;
	}

	double getCost(vector<int> *objs = NULL)
	{
		double maxDiam = 0;
		for(int i=0;i<group.size();i++)
		{
			int o1 = group[i];
			if (objs != NULL)	objs->push_back(o1);
			for(int j=i+1;j<group.size();j++)
			{
				int o2 = group[j];
				double x1 = objLoc[o1].m_pCoords[0], y1 = objLoc[o1].m_pCoords[1];
				double x2 = objLoc[o2].m_pCoords[0], y2 = objLoc[o2].m_pCoords[1];
				double dist = sqrt( (x1-x2) * (x1-x2) + (y1-y2) * (y1-y2));
				if(dist > maxDiam)
					maxDiam = dist;
			}
		}
		cost = alpha * cost + (1-alpha) * maxDiam;
		return cost;
	}

	vector<int> getGroup()
	{
		return group;
	}

	double getRes(Query *oriQ,vector<int> *objs)	//this function is used in the second approximate algorithm
	{
		double res=0, maxDist=0, maxDiam=0;		
		for(int i=0;i<group.size();i++)
		{
			int o1 = group[i];
			double x1 = objLoc[o1].m_pCoords[0], y1 = objLoc[o1].m_pCoords[1];
			objs->push_back(o1);
			double dist = sqrt( (x1-oriQ->x) * (x1-oriQ->x) + (y1-oriQ->y) * (y1-oriQ->y));
			if(dist > maxDist)
				maxDist = dist;

			for(int j=i+1;j<group.size();j++)
			{
				int o2 = group[j];
				double x2 = objLoc[o2].m_pCoords[0], y2 = objLoc[o2].m_pCoords[1];
				double dist = sqrt( (x1-x2) * (x1-x2) + (y1-y2) * (y1-y2));
				if(dist > maxDiam)
					maxDiam = dist;
			}
		}
		res = alpha * maxDist + (1-alpha) * maxDiam;
		return res;
	}

	void getNextEntry(const IEntry& entry, id_type& nextEntry, bool& hasNext)
	{	
		const INode* n = dynamic_cast<const INode*>(&entry);

		if (n != 0)
		{
			int pid = n->getIdentifier();
			string btFile = btreeFolder + MyTool::IntToString(pid);
			char *btfname = new char[btFile.size()+1];
			memcpy(btfname, btFile.c_str(), btFile.size());		
			btfname[btFile.size()] = '\0';
			BTree *bt = new BTree(btfname, 0);	
			
			map<int, vector<int>*> objectTexts;		//the text description of an object
			set<int> indexID;						//the id of child nodes which contains query keywords				
			map<int, vector<int>*>::iterator iterMap;
			for(unsigned int k=0;k<keywords.size();k++)
			{
				int wordID = keywords[k];
				VECTYPE *data = new VECTYPE[DIMENSION];
				bool flag = bt->search(wordID, &data);
				if(flag)
				{					
					for(int i=0;i<DIMENSION;i++)
					{
						if(data[i] > 0)							
						{
							unsigned char mask = 1;
							for(int j=0;j<8;j++)
							{
								if((data[i] & mask) > 0)
								{
									int index = i*8+j;
									indexID.insert(index);
									iterMap = objectTexts.find(index);
									if(iterMap ==  objectTexts.end())
									{
										vector<int> *p = new vector<int>();		
										p->push_back(k);
										objectTexts[index] = p;
									}
									else
									{
										vector<int> *p = iterMap->second;
										p->push_back(k);
									}
								}
								mask = mask << 1;
							}
						}
					}
				}
				delete data;
			}
			delete bt;
			delete btfname;

			set<int>::iterator si = indexID.begin();
			for(;si != indexID.end(); ++si)	
			{
				uint32_t cChild = *si;
				int cid = n->getChildIdentifier(cChild);
				
				IShape *out;
				n->getChildShape(cChild, &out);
				Region* pr = dynamic_cast<Region *>(out);	

				double dx = Q->x - pr->m_pHigh[0];
				double dy = Q->y - pr->m_pHigh[1];											

				int key = MyTool::ConvertToInt(objectTexts[cChild]);
				if( (key & keywordsBM) == 0)
					continue;

				double dist;
				RTreeNode *rtp = new RTreeNode;

				if(n->isLeaf())
				{
					dist = sqrt(dx * dx + dy * dy);
					rtp->isNode = false;
				}
				if(n->isIndex())
				{
					double coor[2];
					coor[0] = Q->x; coor[1] = Q->y;
					Point pt(coor, 2);

					dist = MyTool::ComputeMinPossible(pr, &pt);
					rtp->isNode = true;
				}
				
				rtp->identifier = n->getChildIdentifier(cChild);
				rtp->minValue = dist;
				rtp->bitmap = MyTool::ConvertToInt(objectTexts[cChild]);
				rtp->pr = pr;

				queueNode.push(rtp);
			}
			map<int, vector<int>*>::iterator oi = objectTexts.begin();
			for(; oi != objectTexts.end(); ++oi)
			{
				vector<int> *p = oi->second;
				delete p;
			}
		}

		if (!queueNode.empty())		
		{			
			while (!queueNode.empty())
			{
				RTreeNode *p = queueNode.top();
				queueNode.pop();

				if( p->isNode )		//if the node is not an object, we read the next page.
				{	
					KEYTYPE keyValue = p->bitmap;
					if( (keyValue & keywordsBM) > 0)
					{
						nextEntry = p->identifier;
						hasNext = true;
						delete p;
						break;
					}
				}
				else
				{
					KEYTYPE key = p->bitmap;
					int interS = key & keywordsBM;
					if(interS > 0)		//contains some keywords that have not been covered
					{
						group.push_back(p->identifier);
						keywordsBM = keywordsBM - interS;
						double coor[2];
						coor[0] = p->pr->m_pLow[0];
						coor[1] = p->pr->m_pLow[1];
						Point pp(coor,2);
						objLoc[p->identifier] = pp;

						if(keywordsBM == 0)
						{
							hasNext = false;
							cost = p->minValue;
							//the following code is for the second approximate algorithm
							if(usedInAPP2)
							{
								furthestObj.x = p->pr->m_pLow[0];
								furthestObj.y = p->pr->m_pLow[1];
								KEYTYPE mask = 1;
								for(int i=0;i<sizeof(KEYTYPE) * 8;i++)
								{
									if( (interS & mask) > 0)
									{
										furthestObj.text = MyTool::IntToString(keywords[i]);
										//any word is OK, used for finding next nearest object
										break;
									}
									mask = mask << 1;
								}
							}
							delete p;
							break;
						}
					}
				}
				delete p;
			}
		}
	
		else 
			hasNext = false;
	}
};


class Problem2Appr2: public SpatialIndex::IQueryStrategy
{
private:		
	priority_queue<RTreeNode *, deque<RTreeNode *>, NodeValueLess<RTreeNode> > queueNode;	
	Query *Q;
	int nodeNum;
	vector<int> *group;
	double cost;	
	IBRTree *ibrtree;
	Query fo;	

public:
	Problem2Appr2(Query *Q, int nodeNum)
	{
		this->Q = Q;
		this->nodeNum = nodeNum;		
		this->ibrtree = new IBRTree();
		ibrtree->ReadTree();

		Problem2Appr1 *pb2a1 = new Problem2Appr1(Q, nodeNum, true);
		ibrtree->GetTree()->queryStrategy(*pb2a1);
		fo = pb2a1->furthestObj;
		group = new vector<int>();
		cost = pb2a1->getCost(group);		
		delete pb2a1;
	}

	~Problem2Appr2()
	{
		delete group;
		delete ibrtree;
		while( !queueNode.empty())
		{
			RTreeNode *p = queueNode.top();
			queueNode.pop();
			delete p;
		}
	}

	double getCost()	{return cost;}
	vector<int> * getGroup()	{return group;}

	friend ostream& operator<<(ostream& out,Problem2Appr2 & t)   
	{
		out<<t.cost<<":";
		vector<int>::iterator iter = t.group->begin();
		for(; iter != t.group->end(); ++iter)
			out<<*iter<<" ";
		out<<endl;
		return out;
	}

	void getNextEntry(const IEntry& entry, id_type& nextEntry, bool& hasNext)
	{
		const INode* n = dynamic_cast<const INode*>(&entry);

		if(n!=0)
		{
			int pid = n->getIdentifier();
			string btFile = btreeFolder + MyTool::IntToString(pid);
			char *btfname = new char[btFile.size()+1];
			memcpy(btfname, btFile.c_str(), btFile.size());		
			btfname[btFile.size()] = '\0';
			BTree *bt = new BTree(btfname, 0);	

			set<int> indexID;	//the id of child nodes which contains query keywords						
			
			int wordID = atoi( (fo.text).c_str());
			VECTYPE *data = new VECTYPE[DIMENSION];
			bool flag = bt->search(wordID, &data);
			if(flag)
			{					
				for(int i=0;i<DIMENSION;i++)
				{
					if(data[i] > 0)							
					{
						unsigned char mask = 1;
						for(int j=0;j<8;j++)
						{
							if((data[i] & mask) > 0)
							{
								int index = i*8+j;
								indexID.insert(index);
							}
							mask = mask << 1;
						}
					}
				}
			}
			delete data;		
			delete bt;
			delete btfname;

			set<int>::iterator si = indexID.begin();
			for(;si != indexID.end(); ++si)	
			{
				uint32_t cChild = *si;
				int cid = n->getChildIdentifier(cChild);
				
				IShape *out;
				n->getChildShape(cChild, &out);
				Region* pr = dynamic_cast<Region *>(out);	

				double dx = Q->x - pr->m_pHigh[0];
				double dy = Q->y - pr->m_pHigh[1];											
				
				double dist;
				RTreeNode *rtp = new RTreeNode;

				if(n->isLeaf())
				{
					dist = sqrt(dx * dx + dy * dy);
					rtp->isNode = false;
				}
				if(n->isIndex())
				{
					double coor[2];
					coor[0] = Q->x; coor[1] = Q->y;
					Point pt(coor, 2);

					dist = MyTool::ComputeMinPossible(pr, &pt);
					rtp->isNode = true;
				}
				
				if(alpha * dist < cost)
				{
					rtp->identifier = n->getChildIdentifier(cChild);
					rtp->minValue = dist;			
					rtp->pr = pr;
					queueNode.push(rtp);
				}
				else 
					delete rtp;
			}
		
			while (!queueNode.empty())
			{
				RTreeNode *p = queueNode.top();
				queueNode.pop();

				if( p->isNode )		//if the node is not an object, we read the next page.
				{	
					nextEntry = p->identifier;
					hasNext = true;
					delete p;
					return;
				}
				else
				{
					if(alpha * p->minValue > cost)		//if its distance is already larger than the cost
						break;

					Query *newq = new Query();
					newq->text = Q->text;
					newq->x = p->pr->m_pLow[0];
					newq->y = p->pr->m_pLow[1];

					Problem2Appr1 pb2a1(newq, nodeNum, true);
					ibrtree->GetTree()->queryStrategy(pb2a1);
					vector<int> *objs = new vector<int>();
					double newCost = pb2a1.getRes(Q, objs);
					if(newCost < cost)
					{
						cost = newCost;
						group = objs;
					}
					else
						delete objs;
					
					delete newq;
				}
				delete p;
			}

			hasNext = false;
		}

		else
			hasNext = false;
	}	

};


class NodeSet{
public:
	//set<RTreeNode *, CompRT> nodes;
	vector<RTreeNode *> nodes;
	double minCost;
	double maxDiam;
	double maxDist;
	KEYTYPE bitmap;
    int cite;   

	NodeSet()
	{
		minCost = maxDiam = maxDist = 0.0;
		bitmap = 0;
		cite = 0;
	}

	NodeSet(NodeSet *n)
	{
		this->minCost = n->minCost;
		this->maxDiam = n->maxDiam;
		this->maxDist = n->maxDist;
		this->bitmap = n->bitmap;
		this->nodes = n->nodes;
		cite = 0;
	}

	NodeSet(RTreeNode *rt, double alpha)
	{
		maxDist = rt->minValue;
		maxDiam = 0.0;
		minCost = alpha * rt->minValue;
		bitmap = rt->bitmap;
		nodes.push_back(rt);
		cite = 0;
	}

   static bool CompareValueLess(const NodeSet * a,const  NodeSet * b)
   {
	   return a->minCost > b->minCost;
   }
};

class Problem2Exact2
{
protected:
	Query *Q;
	vector<int> keywords;
	int keywordsnum;
	vector<Object>Obj;
	double lambda;
	double pi;
	double diam;
	
	Grid grid;
	unsigned int keywordsBM;//bitmask
	unsigned int maxKeywordFreqIndex;

	double apprcost;
	double bestcost;//result
	set<int>result;

	map<int, vector<int> >invertedWord; //keywords -> id
	map<int, pair<double, double> >invertedLoc; //id -> location

	//Test Function
	clock_t start, end;
	double timeout;
	vector<int> keywordsFreq;

	//nomalize the angle to 0~2*pi
	double normalizeAngle(double angle){
		while(angle < 0)
			angle += 2*pi;
		while(angle > pi*2)
			angle -= 2*pi;
		return angle;
	}
	double Objdist(const Object &a,const Object &b){
		return  sqrt( (a.x-b.x)*(a.x-b.x) + (a.y-b.y)*(a.y-b.y) );
	}

	double Querydist(const Object &a){
		return sqrt( (a.x-Q->x) * (a.x-Q->x) + (a.y-Q->y) * (a.y-Q->y) );
	}

	void getangle(const Object &a,const Object &b,double &inangle,double &outangle,double diameter){
		double dist = Objdist(a, b);
		double baseangle;
		double x = b.x - a.x;
		double y = b.y - a.y;
		baseangle = atan2(y, x);
		//cerr<<a.x<<","<<a.y<<endl;
		//cerr<<b.x<<","<<b.y<<endl;
		//cerr<<baseangle<<endl;
		double alpha = acos( dist/diameter );
		inangle = normalizeAngle(baseangle - alpha);
		outangle = normalizeAngle(baseangle + alpha);
	}
	virtual inline bool update(double cost){
		bestcost = cost + 0.01;
		return true;
	}
	virtual inline bool update(double cost, const set<int>&group){
		if(cost < bestcost){
			bestcost = cost;
			result = group;
			return true;
		}
		return false;
	}
	virtual inline double bestdist(){
		return bestcost;
	}
public:
	inline bool istimeout(){
		end = clock();
		return (end-start) / CLOCKS_PER_SEC > timeout;
	}

	unsigned int Objnum;

	void show(ostream &out = std::cerr){
#ifdef MCK
		out << diam << " : ";
#else
		out<< bestdist() << ":";
#endif
		double dist = 0;
		double furthest=0;
		int mask = 0;

		for(set<int>::iterator i =result.begin();i!=result.end();i++){
			mask |= Obj[*i].mask;
			for(set<int>::iterator j =result.begin();j!=result.end();j++){
				double len = Objdist(Obj[*i],Obj[*j]);
				if(len>dist)dist = len;
				len = Querydist(Obj[*i]);
				if(len>furthest) furthest = len;
			}
		}
		#ifdef DEBUG
		cerr<<"[DEBUG]review:\n"<<(dist * (1-alpha)+furthest*alpha)<<" mask:"<<mask<<"\n";
		#endif
		for(set<int>::iterator i=result.begin();i!=result.end();i++)
			out<<Obj[*i].oid<<" ";
		out<<endl;
	}

	double getDiameter(){//including query location
		double dist = 0.0;
		for(set<int>::iterator i =result.begin();i!=result.end();i++){
			for(set<int>::iterator j =i;j!=result.end();j++){
				double len = Objdist(Obj[*i],Obj[*j]);
				if(len>dist)dist = len;
			}
			double len = Querydist(Obj[*i]);
			if(len>dist)dist = len;
		}
		return dist;
	}

	void NaiveSKEC(Query *Q, int nodeNum){
		timeout = 60.0;
		start = clock();
		this->Q = Q;
		istringstream iss(Q->text);
		int wid; char c;
		keywords.clear();
		while(iss>>wid)
		{
			keywords.push_back(wid);
			iss>>c;
		}
		keywordsnum = keywords.size();
		keywordsBM = (1 << keywords.size())-1;

		Obj.clear();
		grid.clear();
		SearchIBRTree ss(Q, nodeNum, -1, 1e55);
		IBRTree irtree;
		irtree.ReadTree();
		irtree.GetTree()->queryStrategy(ss);
		
		vector<Object>::iterator iter;
		for(iter = ss.res.begin(); iter != ss.res.end(); iter++){
			//cerr<<iter->second.oid<<" "<<iter->second.mask<<" "<<iter->second.x<<","<<iter->second.y<<endl;
			Obj.push_back(*iter);
			grid.insert(*iter);
		}
		Objnum = Obj.size();
		#ifdef DEBUG
		cerr<<"[DEBUG]Object num: "<<Objnum<<endl;
		#endif
		
		IBRTree *rt = new IBRTree();
		rt->ReadTree();
		Problem2Appr2 pb2a2(Q, nodeNum);
		rt->GetTree()->queryStrategy(pb2a2);
		apprcost = pb2a2.getCost();
		update(apprcost);
		delete rt;

		set<int>group;
		for(int i=0;i<Objnum;i++){
			double x1 = Obj[i].x, y1 = Obj[i].y;
			for(int j = i + 1; j < Objnum; j++){
				#ifdef TIMEOUT
				if(istimeout()) return;
				#endif
				double x2 = Obj[j].x, y2 = Obj[j].y;
				if( ((keywordsBM ^ Obj[i].mask) & Obj[j].mask) == 0 )
					continue;
				if( keywordsBM == (Obj[i].mask | Obj[j].mask) ){
					update(Objdist(Obj[i], Obj[j]), group);
					continue;
				}
				if(Objdist(Obj[i], Obj[j]) > bestdist())
					continue;
				for(int k = j + 1; k < Objnum; k++){
					#ifdef TIMEOUT
					if(istimeout()) return;
					#endif
					double x3 = Obj[k].x, y3 = Obj[k].y;
					if( ((keywordsBM ^ (Obj[i].mask | Obj[j].mask)) & Obj[k].mask) == 0 )
						continue;
					int mask = Obj[i].mask | Obj[j].mask | Obj[k].mask;
					double a=-2*x2*y1 + 2*x3*y1 + 2*x1*y2 - 2*x3*y2 - 2*x1*y3 + 2*x2*y3;
					double b=x3*x3* (y1 - y2) + x1*x1* (y2 - y3) + x2*x2* (-y1 + y3)+(y1 - y2)*(y1 - y3)*(y2 - y3);
					double c=-2*x2*y1 + 2*x3*y1 + 2*x1*y2 - 2*x3*y2 - 2*x1*y3 + 2*x2*y3;
					double d=-x1*x1* x2 + x1*x2*x2 + x1*x1*x3 - x2*x2* x3 - x1*x3*x3 + x2*x3*x3 - x2*y1*y1 +
						x3*y1*y1 + x1*y2*y2 - x3*y2*y2 - x1*y3*y3 + x2*y3*y3;
					double x = b / a, y = d / c;
					double radius = sqrt( (x-x1)*(x-x1) + (y-y1)*(y-y1) );
					if(radius * 2 > bestdist())
						continue;
					for(int p = 0; p < Objnum;p++){
						#ifdef TIMEOUT
						if(istimeout()) return;
						#endif
						if( (x-Obj[p].x)*(x-Obj[p].x) + (y-Obj[p].y)*(y-Obj[p].y) > radius * radius )
							continue;
						mask |= Obj[p].mask;
					}
					if(mask == keywordsBM)
						update(radius * 2, group);
				}
			}
		}
	}

	virtual void Test(Query *Q, int nodeNum)
	{
		timeout = 60;
		start = clock();

		lambda = sqrt(3.0)/2;
		pi = acos(-1.0);

		this->Q = Q;

		IBRTree *rt = new IBRTree();
		rt->ReadTree();
		Problem2Appr2 pb2a2(Q, nodeNum);
		rt->GetTree()->queryStrategy(pb2a2);
		apprcost = pb2a2.getCost();
		update(apprcost);
		delete rt;
		/*
		vector<int> *iniGroup = pb2a2.getGroup();
		vector<int>::iterator vi = iniGroup->begin();
		for(; vi != iniGroup->end(); ++vi)
		{
			//result.insert(*vi);
		}
		*/
		
		istringstream iss(Q->text);
		int wid; char c;
		keywords.clear();
		while(iss>>wid)
		{
			keywords.push_back(wid);
			iss>>c;
		}
		keywordsnum = keywords.size();
		keywordsBM = (1 << keywords.size())-1;
		
		Obj.clear();
		grid.clear();
		result.clear();

		#ifdef DEBUG
		cerr<<"[DEBUG]"<<bestdist()<<endl;
		#endif

		SearchIBRTree ss(Q, nodeNum, -1, 1e55);
		IBRTree irtree;
		irtree.ReadTree();
		irtree.GetTree()->queryStrategy(ss);
		
		vector<Object>::iterator iter;
		for(iter = ss.res.begin(); iter != ss.res.end(); iter++){
			//cerr<<iter->second.oid<<" "<<iter->second.mask<<" "<<iter->second.x<<","<<iter->second.y<<endl;
			Obj.push_back(*iter);
			grid.insert(*iter);
		}
		Objnum = Obj.size();
		#ifdef DEBUG
		cerr<<"[DEBUG]Object num: "<<Objnum<<endl;
		#endif
		grid.init();
		Process2();
	}

	void TestMCK(Query *Q, ostream &mckDocF, ostream &mckLocF)
	{
		istringstream iss(Q->text);
		int wid; char c;
		keywords.clear();
		int lowfreqidx = -1;
		while(iss>>wid)
		{
			keywords.push_back(wid);
			iss>>c;
			if(lowfreqidx == -1 || invertedWord[wid].size() < invertedWord[lowfreqidx].size())
				lowfreqidx = wid;
		}
		//cerr << "Lowfreq word: " << lowfreqidx << " Freq: " << invertedWord[lowfreqidx].size() <<  endl;
		//remove lowest frequence word
		for(vector<int>::iterator it = keywords.begin(); it != keywords.end(); it++)
		{
			if(*it == lowfreqidx){
				keywords.erase(it);
				break;
			}
		}
		
		std::ostringstream oss;
		for(vector<int>::iterator it = keywords.begin(); it != keywords.end(); it++)
			if(it != keywords.begin())
				oss << "," << *it;
			else
				oss << *it;
		string newQdoc = oss.str();
		keywordsnum = keywords.size();
		keywordsBM = (1 << keywords.size())-1;
		
		vector<int> queryLoc = invertedWord[lowfreqidx];
		diam = -1.0;
		for(unsigned i = 0; i < queryLoc.size(); i++){
			int curid = queryLoc[i];
			mckDocF << newQdoc << endl;
			mckLocF << invertedLoc[curid].first << "," << invertedLoc[curid].second << endl;
			
			Query* newQ = new Query(newQdoc, invertedLoc[curid].first, invertedLoc[curid].second);
			//Test(newQ, nodeNum);
			//double res = getDiameter();
			//if(diam < -0.5 || res < diam)
			//	diam = res;
			//cerr << "Query index: " << curid << " Loc: " << invertedLoc[curid].first << "," << invertedLoc[curid].second << endl;
			//cerr << "Cost: " << res << endl;
		}
	}

	Problem2Exact2(){
		/*
		//Added for mCK problem
		cerr << "Loading loc & doc files" << endl;
		ifstream textF(textFile.c_str());
		ifstream locF(locFile.c_str());

		int count = 0;
		while ( !textF.eof() )
		{
			string docLine;
			getline(textF, docLine);
			if(docLine == "")
				continue;
			string locLine;
			getline(locF, locLine);

			istringstream iss(docLine);			
			int oid, wid; char c;
			iss>>oid;
			while(iss >> c >> wid)
			{
				if(invertedWord.count(wid) == 0)
					invertedWord[wid] = vector<int>();
				invertedWord[wid].push_back(count);
			}

			istringstream iss2(locLine);
			double x, y;
			iss2 >> oid >> c >> x >> c >> y;
			invertedLoc[count] = make_pair(x, y);

			count++;
		}
		textF.close();
		locF.close();
		*/
	}

	~Problem2Exact2()
	{
	}

	virtual void search(const vector<int>&curset, set<int>selected, int mask, double pairdist, double furthest, int inc){
		#ifdef TIMEOUT
		if(istimeout()) return;
		#endif

		if(mask == keywordsBM){
			if(pairdist * (1 - alpha) + furthest * alpha < bestdist()){
				update(pairdist * (1 - alpha) + furthest * alpha, selected);
			}
			return ;
		}
		if(pairdist * (1 - alpha) + furthest * alpha > bestdist())
			return;
		vector<int>nextset;
		vector<double>nextlen;
		int nextmask = 0;
		for(vector<int>::const_iterator i = curset.begin(); i!= curset.end(); i++){
			if( (Obj[*i].mask & (keywordsBM^mask)) == 0 )
				continue;
			if( Obj[*i].oid < inc )
				continue;
			double len = pairdist;
			for(set<int>::iterator j=selected.begin();j!=selected.end();j++){
				double dist = Objdist(Obj[*i], Obj[*j]);
				if(len < dist){
					len = dist;
				}
			}
			if(len * (1 - alpha) + furthest * alpha> bestdist())
				continue;
			nextlen.push_back(len);
			nextset.push_back(*i);
			nextmask |= Obj[*i].mask;
		}

		if( (nextmask|mask) != keywordsBM)
			return;

		for(unsigned i = 0; i < nextset.size(); i++){
			int id = nextset[i];
			selected.insert(id);
			search(nextset, selected, mask | Obj[id].mask, max(nextlen[i], pairdist), furthest, Obj[id].oid);
			selected.erase(id);
		}
	}

	//enumerate the furthest object to fix the second cost
	//select the furthest object then search
	void checkcircle(const vector<int>& candidates, const vector<int>& selectedSet, double qdist){
		#ifdef TIMEOUT
		if(istimeout()) return;
		#endif
		int basemask = 0;
		set<int> selected;
		double selectedPairDist = 0.0;
		for(unsigned i = 0; i < selectedSet.size(); i++){
			qdist = max(qdist, Querydist(Obj[selectedSet[i]]));
			basemask |= Obj[ selectedSet[i] ].mask;
			selected.insert(selectedSet[i]);

			for(unsigned j = i+1; j < selectedSet.size(); j++){
				selectedPairDist = max(selectedPairDist, Objdist(Obj[selectedSet[i]], Obj[selectedSet[j]]));
			}
		}

		vector<pair<double, int> > obj_by_dist;
		for(vector<int>::const_iterator it = candidates.begin(); it != candidates.end(); it++){
			if(Obj[*it].mask & (keywordsBM ^ basemask))
				obj_by_dist.push_back(make_pair(Querydist(Obj[*it]), *it));
		}

		int checkmask = basemask;
		sort( obj_by_dist.begin(), obj_by_dist.end());
		vector<int>nextset;

		if(checkmask == keywordsBM){
			search(nextset, selected, basemask, selectedPairDist, qdist, 0);
		}

		for(unsigned i = 0; i < obj_by_dist.size(); i++){
			#ifdef TIMEOUT
			if(istimeout()) return;
			#endif
			double dist = obj_by_dist[i].first;
			int idx = obj_by_dist[i].second;

			if(max(qdist, dist) * (alpha) + Objdist(Obj[idx], Obj[selectedSet[0]]) * (1 - alpha) > bestdist())
				continue;

			nextset.push_back(idx);
			checkmask |= Obj[idx].mask;

			//pruning
			if(i + 1 < obj_by_dist.size() &&  obj_by_dist[i+1].first < qdist)
				continue;

			if(checkmask == keywordsBM){
				if(dist < qdist){ //This object is not the furthest
					search(nextset, selected, basemask, selectedPairDist, qdist, 0);
				}
				else{ //This object is the furthest
					selected.insert(idx);
					double pairDist = selectedPairDist;
					for(unsigned i = 0; i < selectedSet.size(); i++)
						pairDist = max(pairDist, Objdist(Obj[selectedSet[i]], Obj[idx]));
					search(nextset, selected, basemask|Obj[idx].mask, pairDist, max(qdist, dist), 0);
					selected.erase(idx);
				}
			}
		}
	}

	/*
	bool sweep(int pivot, double diameter, bool ischeck){
		double furthest = Querydist(Obj[pivot]);
		if(ischeck)
			diameter /= lambda / 2;
		
		//vector<int> near = grid.query(Obj[pivot].x, Obj[pivot].y, diameter, keywordsBM ^ Obj[pivot].mask, Q->x, Q->y, furthest);
		vector<int> near = grid.query(Obj[pivot].x, Obj[pivot].y, diameter, keywordsBM ^ Obj[pivot].mask);

		int mask = Obj[pivot].mask;
		int circle = 0;
		for(unsigned j=0;j<near.size();j++){
			mask |= Obj[near[j]].mask;
		}
		if(mask != keywordsBM)
			return false;

		bool ret = false;
		mask = keywordsBM ^ Obj[pivot].mask; //target mask
		vector<int>countBitmask(keywordsnum,0);
		int curmask = 0;
		
		priority_queue<pair<double,int>,vector<pair<double,int> >, greater<pair<double,int> > >inqueue;
		priority_queue<pair<double,int>,vector<pair<double,int> >, greater<pair<double,int> > >outqueue;
		map<int,double>outangleMap;//index -> outangle
		set<int>curset;//current objects set
		curset.insert(pivot);
		double curangle = 0;
		for(unsigned j=0;j<near.size();j++){
			Object next = Obj[near[j]];
			double inangle,outangle;
			getangle( Obj[pivot], Obj[near[j]],inangle,outangle,diameter);
			
			if(outangle < inangle){
				outangle += 2*pi;
				outangleMap[near[j]] = outangle;
				outqueue.push(pair<double,int>(outangle, near[j]) );
				curset.insert(near[j]);
				for(int k=0;k<keywordsnum;k++)
					if( (mask & (1<<k)) && (Obj[near[j]].mask & (1<<k) )){
						countBitmask[k]++;
						curmask |= 1<<k;
					}
			}
			else{
				outangleMap[near[j]] = outangle;
				inqueue.push(pair<double,int>(inangle, near[j]));
			}
		}
		if(curmask == mask){
			ret = true;
			if(ischeck)
				circle ++;
			else
				return ret;
			if(ischeck){
				vector<int>selected;
				selected.push_back(pivot);
				checkcircle(curset, selected, furthest);
			}
		}
		set<int>batchcheck;
		while(inqueue.size() > 0){
			double add = inqueue.top().first - curangle;
			if(outqueue.size() == 0 || (outqueue.top().first- curangle) > add){
				int in = inqueue.top().second;
				curset.insert(in);
				outqueue.push(pair<double, int>(outangleMap[in], in));
				bool inc = false;
				for(int k=0;k<keywordsnum;k++)
					if( (mask & (1<<k)) && (Obj[in].mask & (1<<k) )){
						countBitmask[k]++;
						if( (curmask&(1<<k))==0 )
							inc = true;
						curmask |= 1<<k;
					}
				curangle += add;
				inqueue.pop();
				if(curmask == mask){
					ret = true;
					if(ischeck)
						circle ++;
					else
						break;
					if(ischeck){
						if(batchcheck.size() == 0)
							batchcheck = curset;
						else
							batchcheck.insert(in);
					}
				}
				else if(ischeck){
					if(batchcheck.size() > 0){
						vector<int>selected;
						selected.push_back(pivot);
						checkcircle(batchcheck, selected, furthest);
						batchcheck.clear();
					}
				}
			}
			else{
				int out = outqueue.top().second;
				curset.erase(out);
				for(unsigned k=0;k<keywordsnum;k++)
					if( (mask & (1<<k)) && (Obj[out].mask & (1<<k) )){
						countBitmask[k]--;
						if(countBitmask[k] == 0)
							curmask ^= 1<<k;
					}
				curangle = outqueue.top().first;
				outqueue.pop();
			}
		}
		if(batchcheck.size() > 0){
			vector<int>selected;
			selected.push_back(pivot);
			checkcircle(batchcheck, selected, furthest);
			batchcheck.clear();
		}
		//if(ischeck)
		//	cerr << "loc: "<<circle<<endl;
		return ret;
	}
	*/

	bool combinationCheck(int pivot, const vector<Object>& lowFreqObj){
		
		double qdist = Querydist(Obj[pivot]);
		double diameter = (bestdist() - qdist);
		vector<int> near;
		
		int xorMask = Obj[pivot].mask;

		for(unsigned i = 0;i < lowFreqObj.size(); i++){
			double furthest = max(qdist, Querydist(lowFreqObj[i]));
			double pairDist = Objdist(Obj[pivot], lowFreqObj[i]);

			if(furthest + pairDist > bestdist()){
				continue;
			}

			if(near.size() == 0){
				near = grid.query(Obj[pivot].x, Obj[pivot].y, diameter, keywordsBM ^ Obj[pivot].mask);
			}

			for(unsigned j = 0; j < near.size(); j++){
				int id = near[j];
				//double pairDist = Objdist(Obj[id], Obj[pivot]);
				double pairdist = max(Objdist(Obj[id], Obj[pivot]), Objdist(Obj[id], lowFreqObj[i]));

				if(max(furthest, Querydist(Obj[id])) + max(pairDist, pairdist) > bestdist()){
					continue;
				}
				xorMask |= Obj[id].mask | lowFreqObj[i].mask;
			}
		}
		if(keywordsBM == xorMask){
			return true;
		}
		else{
			//remove from data set
			grid.del(Obj[pivot]);
			return false;
		}
	}

	/*
	void Process(){
		//try to combine with low freq objects
		vector<pair<int, int> >keywordscnt;
		for(unsigned i = 0; i < keywordsnum; i++)
			keywordscnt.push_back( make_pair(0, i) );

		for(unsigned i = 0;i < Objnum;i++)
			for(unsigned j = 0; j < keywordsnum; j++)
				if(Obj[i].mask & (1<<j))
					keywordscnt[j].first++;
		sort(keywordscnt.begin(), keywordscnt.end());
		for(unsigned i = 0; i < keywordsnum; i++)
			keywordsFreq.push_back(keywordscnt[i].second);

		unsigned minKeywordFreqIndex = keywordscnt[0].second;
		unsigned maxKeywordFreqIndex = keywordscnt[keywordsnum-1].second;
		cerr<<"[DEBUG]Min freq wordcount: "<< keywordscnt[0].first <<endl;

		vector<Object>lowFreqObj;
		for(unsigned i = 0;i < Objnum; i++)
			if(Obj[i].mask & (1<<minKeywordFreqIndex))
				lowFreqObj.push_back( Obj[i] );
		this->maxKeywordFreqIndex = maxKeywordFreqIndex;

		//cout<<"Objnum: "<<Objnum<<endl;

		int delcount = 0;
		vector<pair<double, int> >candidate_pivot;
		for(int pivot = 0; pivot < Objnum; pivot++){
			//if low-freq objects no too much
			//remove from data set
			if(!combinationCheck(pivot, lowFreqObj)){
				grid.del(Obj[pivot]);
				delcount++;
				continue;
			}
			else{
				candidate_pivot.push_back(make_pair(Querydist(Obj[pivot]), pivot));
			}
		}
		cerr<<"[DEBUG]Delete: "<< delcount <<endl;
		cerr<<"[DEBUG]Left: "<<candidate_pivot.size()<<endl;

		sort(candidate_pivot.begin(), candidate_pivot.end() );

		for(unsigned i = 0; i < candidate_pivot.size(); i++){
			//if(istimeout()) return;

			int pivot = candidate_pivot[i].second;
			if(candidate_pivot[i].first > bestdist())
				break;
			double qdist = Querydist(Obj[pivot]);
			double low  = 0;
			double high = (bestdist() - qdist);
			double eps  = 1e-2;
			double diameter;

			//if only one object
			if(Obj[pivot].mask == keywordsBM){
				set<int>group;
				group.insert(pivot);
				update(qdist, group);
				continue;
			}

			//if max frequence keyword contained
			//sweeping with this object can be ignored
			
			if(Obj[pivot].mask == (1 << maxKeywordFreqIndex))
				continue;
			
			//The largest circle doesn't contain feasible position
			if( !sweep(pivot, high, false) )
				continue;

			//binary search for minumum feasible circle diameter
			while(high - low > eps){
				double mid = (high + low) / 2;
				if( sweep(pivot, mid, false) ){
					diameter = high = mid;
				}
				else{
					low = mid;
				}
			}
			if(qdist + diameter * lambda < bestdist()){
				sweep(pivot, diameter, true);
			}
		}
	}
	*/

	/*
		Low frequency keywords based algorithm
	*/
	void Process2(){
		//try to combine with low freq objects
		vector<pair<int, int> >keywordscnt;
		for(unsigned i = 0; i < keywordsnum; i++)
			keywordscnt.push_back( make_pair(0, i) );

		for(unsigned i = 0;i < Objnum;i++)
			for(unsigned j = 0; j < keywordsnum; j++)
				if(Obj[i].mask & (1<<j))
					keywordscnt[j].first++;
		sort(keywordscnt.begin(), keywordscnt.end());
		for(unsigned i = 0; i < keywordsnum; i++)
			keywordsFreq.push_back(keywordscnt[i].second);

		unsigned minKeywordFreqIndex = keywordscnt[0].second;
		unsigned maxKeywordFreqIndex = keywordscnt[keywordsnum-1].second;

		#ifdef DEBUG
		cerr<<"[DEBUG]Min freq wordcount: "<< keywordscnt[0].first <<endl;
		#endif

		vector<pair<double, int> >lowFreqIndex;
		for(unsigned i = 0;i < Objnum; i++)
			if(Obj[i].mask & (1<<minKeywordFreqIndex)){
				lowFreqIndex.push_back( make_pair(Querydist(Obj[i]), i) );
			}
		sort(lowFreqIndex.begin(), lowFreqIndex.end());
		this->maxKeywordFreqIndex = maxKeywordFreqIndex;

		for(unsigned i = 0; i < lowFreqIndex.size(); i++){
			//cout << "??" << endl;
			vector<int>selectedSet;
			int id = lowFreqIndex[i].second;
			selectedSet.push_back(id);
			vector<int>candidates;
			int mask = Obj[id].mask;
			if(Querydist(Obj[id]) * alpha > bestdist())
				continue;
			for(unsigned j = 0; j < Objnum; j++){
				if( (Obj[j].mask & (keywordsBM ^ Obj[id].mask)) == 0 )
					continue;
				if( max(Querydist(Obj[id]), Querydist(Obj[j])) * alpha + Objdist(Obj[id], Obj[j]) * (1-alpha) > bestdist())
					continue;
				candidates.push_back(j);
				mask |= Obj[j].mask;
			}
			if(mask != keywordsBM)
				continue;

			#ifdef DEBUG
			if(candidates.size())
				cerr<<"[DEBUG]Candidate Number:"<<candidates.size()<<endl;
			#endif
			checkcircle(candidates, selectedSet, Querydist(Obj[id]));
		}
	}
};

class Problem2Topk: public Problem2Exact2
{
protected:
	priority_queue<pair<double, set<int> > >Topk;
	int ksize;
	inline bool update(double cost, const set<int>& group){
		if(Topk.size() < ksize){
			Topk.push(make_pair(cost, group));
			return true;
		}
		else{
			if(Topk.top().first < cost){
				return false;
			}
			else{
				Topk.push(make_pair(cost, group));
				Topk.pop();
				return true;
			}
		}
	}
	inline bool update(double cost){
		set<int>group; //empty set, just for update, should not be a real result!!
		double eps = 1e-5;
		return update(cost + eps, group);
	}
	inline double bestdist(){
		if(Topk.empty())
			return -1.0;
		if(Topk.size()<ksize)
			return Topk.top().first;
		return Topk.top().first;
	}
public:
	void show(ostream &out = std::cerr){
		priority_queue<pair<double, set<int> > > res = Topk;
		while(!res.empty()){
			pair<double, set<int> >cur = res.top();
			res.pop();
			double dist = 0;
			double furthest = 0;
			int mask = 0;
			set<int> result = cur.second;
			if(result.size() == 0)
				continue;
			for(set<int>::iterator i =result.begin();i!=result.end();i++){
				mask |= Obj[*i].mask;
				for(set<int>::iterator j =result.begin();j!=result.end();j++){
					double len = Objdist(Obj[*i],Obj[*j]);
					if(len>dist) dist = len;
					len = Querydist(Obj[*i]);
					if(len>furthest)furthest = len;
				}
			}
			
			out<<"Top-"<<res.size() + 1<<" : "<<cur.first/2<<" :";
			#ifdef DEBUG
			cerr<<"[DEBUG]review:\n"<<(dist+furthest)/2<<" mask:"<<mask<<"\n";
			#endif
			for(set<int>::iterator i=result.begin();i!=result.end();i++)
				out<<Obj[*i].oid<<" ";
			out<<endl;
		}
		out<<endl;
	}
	
	Problem2Topk(){}
	
	~Problem2Topk(){}

	void TopkTest(Query *Q, int nodeNum, IBRTree *irtree, int ksize){
		this->ksize = ksize;
		while(!Topk.empty())
			Topk.pop();
		Test(Q, nodeNum, irtree);
	}

	set<Object> vec2set(vector<Object>vt){
		set<Object> ret;
		for(unsigned i = 0;i < vt.size(); i++)
			ret.insert(vt[i]);
		return ret;
	}

	void Test(Query *Q, int nodeNum, IBRTree *irtree)
	{
		timeout = 5 * 60;
		start = clock();

		pi = acos(-1.0);

		this->Q = Q;

		MaxmaxTopkAppr topkappr;
		topkappr.Test(Q, nodeNum, ksize, irtree);//
		vector<vector<Object> >apprResult = topkappr.getResult();

		for(unsigned i = 0;i < ksize; i++){
			update(topkappr.getCost(apprResult[apprResult.size() - 1]) * 2);
		}
		
		istringstream iss(Q->text);
		int wid; char c;
		keywords.clear();
		while(iss>>wid)
		{
			keywords.push_back(wid);
			iss>>c;
		}
		keywordsnum = keywords.size();
		keywordsBM = (1 << keywords.size())-1;
		
		Obj.clear();
		grid.clear();
		result.clear();

		#ifdef DEBUG
		cerr<<"[DEBUG]"<<bestdist()/2<<endl;
		#endif

		SearchIBRTree ss(Q, nodeNum, -1, bestdist());
		irtree->ReadTree();
		irtree->GetTree()->queryStrategy(ss);
		
		vector<Object>::iterator iter;
		for(iter = ss.res.begin(); iter != ss.res.end(); iter++){
			//cerr<<iter->second.oid<<" "<<iter->second.mask<<" "<<iter->second.x<<","<<iter->second.y<<endl;
			Obj.push_back(*iter);
			grid.insert(*iter);
		}
		Objnum = Obj.size();
		#ifdef DEBUG
		cerr<<"[DEBUG]Object num: "<<Objnum<<endl;
		#endif
		grid.init();
		Process2();
	}
};

#endif