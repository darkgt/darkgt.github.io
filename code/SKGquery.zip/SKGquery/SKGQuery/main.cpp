/* Author: Xin Cao 
 * Email: xcao1@e.ntu.edu.sg 
 *
 * Notice that the exact algorithm for TYPE2 query does not work well on queries with too many keywords, or very frequent keyword
 * This is because that the exhaustive search needs too many enumerations in those cases.
 * Please first call IBRTree.BuildIBRTree() to build the index. Then, comment IBRTree.BuildIBRTree() and test the queries.
 * 
 */
#include <time.h>
#include <iostream>

#include "IBRTree.h"
#include "SearchIBRTree.h"
#include "Problem1.h"
#include "Problem2.h"
#include "Problem3.h"
#include "topkbase.h"

using namespace std;

string basepath = "..\\NewYork\\";

string locFile = basepath + "loc";
string treeFile = basepath + "rtree";
string textFile = basepath + "doc";
string invertedFile = basepath + "invertedfile";

string btreeFolder = basepath + "btreeindex\\";
string leafnodeFile = basepath + "leafnodes";
string indexnodeFile = basepath + "indexnodes";
string subdocFolder = basepath + "subdoc\\";
string invertedFolder = basepath + "inverted\\";

string queryFolder = basepath +"query\\";
//string queryLoc = queryFolder + "queryLoc_4";

string queryDoc = queryFolder + "queryDoc8";
string resultFile =  queryDoc + "naive";

string newqueryDoc = queryDoc + "_skgdoc";
string newqueryLoc = queryDoc + "_skgloc";

int numOfEntry = NODENUM;		//For hotel data, the fanout of R-tree is 40. it must be consistent with NODENUM defined in data.h!
double alpha = 0.0;

#define FRESULT

//#define MCK

int main()
{
	//cout << "?" << endl;
	IBRTree irtree;
	//irtree.BuildIBRTree();return 0;
	
	irtree.ReadTree();
	
	IStatistics *out;
	irtree.GetTree()->getStatistics(&out);
	int nodeNum = out->getNumberOfData();
	
	Query *Q = new Query("2,5", 44, -151);

	clock_t start, finish;
	///*
	//ifstream locF(queryLoc.c_str());
	ifstream docF(queryDoc.c_str());
	
	int casenum = 0;
	int validcase = 0;
	double tottime = 0;

	Problem2Exact2 pb2et;
	Problem3Exact pb3et;
	//Problem2Topk pb2topk;
	
	#ifdef FRESULT
	ofstream fout;
	fout.open(resultFile);
	ostream &myout = fout;
	#else
	ostream &myout = std::cout;
	#endif

	//ofstream sdocF(newqueryDoc.c_str());
	//ofstream slocF(newqueryLoc.c_str());

	//while(!locF.eof() && !docF.eof()){
	while(!docF.eof()){
		string line;
		//getline(locF, line);
		//if(line == ""){
		//	getline(docF, line);
		//	continue;
		//}
		double x= -1.0, y = -1.0;
		//sscanf( line.c_str(), "%lf,%lf", &x, &y);
		getline(docF, line);
		if(line == "")
			continue;
		Q = new Query(line, x, y);

		cout<<"Case:"<<++casenum<<endl;
		start = clock();

		/*
		Problem1DP pb1edp(Q);
		pb1edp.BaseLine();
		finish = clock();
		cout<<pb1edp;
		*/
		
		/*
		Problem1IBRTree pb1e2(Q, nodeNum);
		irtree.GetTree()->queryStrategy(pb1e2);
		finish = clock();
		cout<<pb1e2;
		*/

		/*
		Problem1Topk pb1e1topk(Q, 5);
		pb1e1topk.BaseLine();
		finish = clock();
		cout<<pb1e1topk;
		*/

		/*
		Problem1IBRTreeTopk pb1e2topk(Q, 5, nodeNum);
		irtree.GetTree()->queryStrategy(pb1e2topk);
		finish = clock();
		cout<<pb1e2topk;
		*/

		//Problem2Appr2 pb2a2(Q, nodeNum);
		//irtree.GetTree()->queryStrategy(pb2a2);
		//finish = clock();
		//myout<<pb2a1;
		
		
		Problem2Exact2 pb2e;
		pb2e.NaiveSKEC(Q, nodeNum);
		pb2e.show(myout);
		//irtree.GetTree()->queryStrategy(pb2e);
		finish = clock();
		//cout<<pb2e;

		
		//pb2et.TestMCK(Q, sdocF, slocF);

		finish = clock();
		//if(pb2et.istimeout()){
		//	myout<<endl;
		//	continue;
		//}
		//pb2et.show(myout);
		validcase++;
		
		
		/*
		pb3et.Test(Q, nodeNum);
		finish = clock();
		if(pb3et.istimeout()){
			myout<<endl;
			continue;
		}
		pb3et.show(myout);
		validcase++;
		*/

		/*
		MinmaxTopkAppr pb2ta;
		pb2ta.Test(Q, nodeNum, 5, &irtree);
		finish = clock();
		myout<<pb2ta;
		validcase++;
		*/

		/*
		Problem3Topk pb3tk;
		pb3tk.TopkTest(Q, nodeNum, &irtree, 5);
		finish = clock();
		pb3tk.show(myout);
		validcase++;
		*/

		/*
		Problem2Appr2 pb2a2(Q, nodeNum);
		irtree.GetTree()->queryStrategy(pb2a2);
		double cost = pb2a2.getCost();
		cerr<<cost*2<<endl;
		SearchIBRTree ss(Q, nodeNum, -1, cost * 2 + 0.01);
		irtree.GetTree()->queryStrategy(ss);
		cout<<ss.res.size()<<endl;
		finish = clock();
		*/

		/*
		pb2topk.TopkTest(Q, nodeNum, 5);
		pb2topk.BaseLine();
		finish = clock();
		pb2topk.show();
		*/

		tottime += finish - start;
	}

	//sdocF.close();
	//slocF.close();
	
	myout<< tottime / CLOCKS_PER_SEC / validcase<<endl;
	myout<<"Valid case: "<<validcase<<endl;

	#ifdef FRESULT
	fout.close();
	#endif
	//*/

	//getchar();
	return 0;
}