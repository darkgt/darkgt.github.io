#include "Problem2.h"

bool Problem2Exact2::EnumerateMultiNode(bool isLeaf)
{
	vector<NodeSet *> *combination = new vector<NodeSet *>;

	int min = 1<<31-1, rare;
	for(unsigned int i=0;i<keywords.size(); i++)			//find the word coveres by the least nodes
	{
		int temp = inverted[i].size();
		if(temp < min)
		{
			min = temp;
			rare = i;
		}
	}

	vector< vector<RTreeNode *> * >::iterator iter = setLists.begin();		
	map<int, int> node2idx;
	vector<int> sizes;
	vector<NodeSet *> *L = new vector<NodeSet *>();
	int index = 0;

	for(; iter != setLists.end(); ++iter)		//get each node's child nodes, and filter out some of them
	{
		vector<RTreeNode *> *p = *iter;
		vector<RTreeNode *>::iterator ni;
		int count = 0;
		for(ni = p->begin(); ni!= p->end(); ++ni)
		{
			RTreeNode *rtp = (*ni);

			bool satisfied = false;
			for(int i=0;i<inverted[rare].size();i++)	//compute the distance between a node and each node covering the infrequent word
			{
				RTreeNode *t = inverted[rare][i];
				if( rtp == t)
				{
					count++;
					satisfied = true; 
					break;
				}
				RTreeNode *rtp2 = t;
				double maxDist = rtp->minValue > t->minValue ? rtp->minValue : t->minValue;
				double diam;
				if(!isLeaf)
					diam = ComputeMBRDist(rtp->pr, rtp2->pr);
				else
				{
					double dx = rtp->pr->m_pLow[0] - rtp2->pr->m_pLow[0];
					double dy = rtp->pr->m_pLow[1] - rtp2->pr->m_pLow[1];
					diam = sqrt(dx * dx + dy * dy);
				}
				if((1-alpha) * diam + alpha * maxDist < Cost)		//can be combined with one node is ok
				{
					count++;
					satisfied = true;
					break;
				}
			}
			if(satisfied)					//insert this node into L
			{
				int nid = rtp->identifier;
				node2idx[nid] = index;		//map the node' ID to its parent node's position
				NodeSet *nn = new NodeSet(rtp, alpha);
				L->push_back(nn);
			}
		}
		sizes.push_back(count);
		//delete p;		//setLists���vector *���ͷ�, ������ת����L��
		index ++;
	}//the first filtering step, must at least can be combined with one node covering the rare word (do more?)

	vector<NodeSet *> *Li = new vector<NodeSet *>;

	KEYTYPE levelBM = 0;

	set<long long> mutexpairs;
	set<long long>::iterator pairIter;
	map<long long, double> pairDist;
	
	for(unsigned int m=0;m<L->size();m++)
	{
		NodeSet * p1 = (*L)[m];

		for(unsigned int n=m+1;n<L->size();n++)
		{
			NodeSet * p2 = (*L)[n];

			KEYTYPE ubm = p1->bitmap | p2->bitmap;
			int num = MyTool::getNumOf1(ubm);
			if( num < 2)
				continue;

			RTreeNode *rtp1 = (p1->nodes)[0];
			RTreeNode *rtp2 = (p2->nodes)[0];
			long long key = ( (long long)rtp1->identifier << 32 ) + rtp2->identifier;

			double diam;
			if(!isLeaf)
				diam = ComputeMBRDist(rtp1->pr, rtp2->pr);
			else
			{
				double dx = rtp1->pr->m_pLow[0] - rtp2->pr->m_pLow[0];
				double dy = rtp1->pr->m_pLow[1] - rtp2->pr->m_pLow[1];		
				diam = sqrt(dx *dx + dy * dy);
			}
			pairDist[key] = diam;
			double maxDist = p1->maxDist > p2->maxDist ? p1->maxDist : p2->maxDist;
			double minCost = (1-alpha) * diam + alpha * maxDist;
			if(minCost < Cost)
			{
				NodeSet *p = new NodeSet();
				p->nodes.insert(p->nodes.begin(), p1->nodes.begin(), p1->nodes.end());
				p->nodes.push_back( (p2->nodes)[0]);
				p->bitmap = ubm;
				p->maxDiam = diam;
				p->maxDist = maxDist;
				p->minCost = minCost;
				Li->push_back(p);
				levelBM = levelBM | ubm;
			}		
			else
			{
				mutexpairs.insert(key);
			}
		}
	}
	vector<NodeSet *>::iterator ni = L->begin();
	for(; ni != L->end(); ++ni)
	{	
		//if( (*ni)->cite == 0)
				delete *ni;;
	}
	delete L; L = Li;
	
	if(levelBM != keywordsBM)
	{
		vector<NodeSet *>::iterator ni = L->begin();
		for(; ni != L->end(); ++ni)
			//if( (*ni)->cite == 0)
				delete *ni;
		delete L;
		
		delete combination;
		return true;
	}

	for(unsigned int i=3;i<=keywords.size();i++)
	{
		vector<NodeSet *> *Li = new vector<NodeSet *>;

		levelBM = 0;

		for(unsigned int m=0;m<L->size();m++)
		{
			NodeSet * p1 = (*L)[m];			
			
			for(unsigned int n=m+1;n<L->size();n++)
			{
				if(istimeout())
				{
					cout<<"timeout-Mul"<<endl;
			
					vector<NodeSet *>::iterator vi;
					for(vi = L->begin(); vi != L->end(); ++vi)
					{
						NodeSet *nn = *vi;
						if(nn->cite == 0)
							delete nn;
					}
					delete L;

					for(vi = combination->begin(); vi != combination->end(); ++vi)
					{
						NodeSet *nn = *vi;
						delete nn;
					}
					delete combination;
					return false;
				}

				NodeSet * p2 = (*L)[n];

				KEYTYPE ubm = p1->bitmap | p2->bitmap;
				int num = MyTool::getNumOf1(ubm);
				if( num < i)
					continue;

				bool sharePrefix = true;		//could be improved!
				for(int k=0;k<i-2;k++)
				{
					if( (p1->nodes)[k] != (p2->nodes)[k])
					{
						sharePrefix = false;
						break;
					}
				}
				if(!sharePrefix)
					break;

				int lastID = (p2->nodes)[i-2]->identifier;		//get ID of the last node in one nodeset to be combined

				int key_num = keywords.size(); int node_num = setLists.size(); 
				int lastPossibleNode = node_num - key_num + i - 1;
				if(node2idx[lastID] < lastPossibleNode)
					//This is to make sure that from the rest node, we can select at least one child node from each of them.
					//For example, A(A1, A2) B(B1, B2) C(C1, C2, C3) D(D1, D2), five keywords t1, t2, t3, t4, t5
					//If we are trying to combine A1A2B1 and A1A2B2, we can get A1A2B1B2, however at least 4 keywords are already
					//covered (each node must cover at least one), and thus only 1 word is left to be covered by C and D.
					//This means that either C or D is not necessary, which contradicts to our assumtion. 
					//Actually, this should be enumerated in the node set A(A1, A2), B(B1, B2), C(C1, C2, C3) {or D(D1, D2)}
					continue;

				RTreeNode *rtp1 = (p1->nodes)[i-2];
				RTreeNode *rtp2 = (p2->nodes)[i-2];
				long long key = ( (long long)rtp1->identifier << 32 ) + rtp2->identifier;

				if( !mutexpairs.empty() && (pairIter = mutexpairs.find(key)) != mutexpairs.end())
					continue;

				double diam = pairDist[key];		
				double maxDist = p1->maxDist > p2->maxDist ? p1->maxDist : p2->maxDist;
				double maxDiam = p1->maxDiam > p2->maxDiam ? p1->maxDiam : p2->maxDiam;
				maxDiam = diam > maxDiam ? diam : maxDiam;
				double minCost = (1-alpha) * maxDiam + alpha * maxDist;					
				if(minCost < Cost)
				{
					NodeSet *p = new NodeSet();
					p->nodes.insert(p->nodes.begin(), p1->nodes.begin(), p1->nodes.end());
					p->nodes.push_back( (p2->nodes)[i-2]);
					p->bitmap = ubm;
					p->maxDiam = maxDiam;
					p->maxDist = maxDist;
					p->minCost = minCost;
					Li->push_back(p);
					levelBM = levelBM | ubm;
				}					
			}
		}

		vector<NodeSet *>::iterator ni = L->begin();
		for(; ni != L->end(); ++ni)
		{
			NodeSet *p = *ni;
			int lastID = p->nodes.back()->identifier;
			if(node2idx[lastID] == setLists.size()-1 && p->nodes.size() >= setLists.size() &&
				p->bitmap == keywordsBM && p->minCost < Cost)
					//if the last node is from the last parent node:; A1A2B1B2C1 is not allowed
			{
				combination->push_back(p);
				p->cite = 1;
			}
			else
				delete p;
		}
		delete L;	L = Li;

		if( levelBM != keywordsBM)		//all possible nodesets do not cover all keywords
			break;
	}

	//do not forget to process the last!
	ni = L->begin();
	for(; ni != L->end(); ++ni)
	{
		NodeSet *p = *ni;
		int lastID = p->nodes.back()->identifier;
		if(node2idx[lastID] == setLists.size()-1 && p->nodes.size() >= setLists.size() &&
			p->bitmap == keywordsBM && p->minCost < Cost)
				//if the last node is from the last parent node:; A1A2B1B2C1 is not allowed
		{
			combination->push_back(p);
			p->cite = 1;
		}
		else
			delete p;
	}
	delete L;

	if(isLeaf)
	{
		vector<NodeSet *>::iterator vi;
		for(vi = combination->begin(); vi != combination->end(); ++vi)
		{
			NodeSet *nn = *vi;
			if(Cost > nn->minCost)
			{
				Cost = nn->minCost;
				delete optimal;
				optimal = new NodeSet(nn);
				//cout<<2<<endl;getchar();
			}
			delete nn;
		}
	}
	else
	{
		vector<NodeSet *>::iterator vi;
		for(vi = combination->begin(); vi != combination->end(); ++vi)
		{
			NodeSet *nn = *vi;
			if(Cost > nn->minCost)
			{
				queueNodeSet.push(nn);

				vector<RTreeNode *>::iterator vi;
				for(vi = nn->nodes.begin(); vi != nn->nodes.end(); ++vi)
					cout<<(*vi)->identifier<<" ";
				cout<<endl;
			}
			else delete nn;
		}
	}
	delete combination;
	return true;
}

bool Problem2Exact2::EnumerateMultiNode(NodeSet *sel, int dupAllowed, int idx, int level, int size, bool isLeaf)
{
	if(istimeout() || queueNodeSet.size() > 2000000)
	{
		return false;
	}

	if(level == setLists.size() || size == 0)
	{
		if(!isLeaf)
		{
			if(sel->bitmap == keywordsBM && sel->cite == 0)
			{
				NodeSet *nn = new NodeSet(sel);
				queueNodeSet.push(nn);
				sel->cite = 1;

				//vector<RTreeNode *>::iterator vi;
				//for(vi = nn->nodes.begin(); vi != nn->nodes.end(); ++vi)
				//	cout<<(*vi)->identifier<<" ";
				//cout<<endl;
			}
		}
		else
		{
			if(sel->bitmap == keywordsBM)
			{
				NodeSet *nn = optimal;
				if(Cost > sel->minCost)
				{
					delete nn;
					nn = new NodeSet(sel);
					Cost = nn->minCost;
				}
				if(nn != optimal)
					optimal = nn;
			}
		}
		return true;
	}

	bool status = true;
	
	if(idx == setLists[level]->size() && level < setLists.size()-1)
	{
		idx = 0;
		level += 1;
	}
	for(int i=idx; i < setLists[level]->size(); i++)
	{
		RTreeNode *rtp = setLists[level]->at(i);

		int nodeNum = sel->nodes.size() + 1;
		KEYTYPE bitmap = sel->bitmap | rtp->bitmap;
		int num = MyTool::getNumOf1(bitmap);
		if(num < nodeNum)
			 continue;

		double maxDist = rtp->minValue > sel->maxDist ? rtp->minValue : sel->maxDist;
		vector<RTreeNode *>::iterator ri = sel->nodes.begin();
		double maxDiam = 0;
		for(; ri != sel->nodes.end(); ++ri)
		{
			RTreeNode *rtp2 = *ri;
			double diam; 
			if(!isLeaf)
				diam = ComputeMBRDist(rtp->pr, rtp2->pr);
			else
			{
				double dx = rtp->pr->m_pLow[0] - rtp2->pr->m_pLow[0];
				double dy = rtp->pr->m_pLow[1] - rtp2->pr->m_pLow[1];
				diam = sqrt(dx *dx + dy * dy);
			}
			if(diam > maxDiam)
				maxDiam = diam;
		}

		if(sel->maxDiam > maxDiam)
			maxDiam = sel->maxDiam;
		double minCost = alpha * maxDist + (1-alpha) * maxDiam;

		if(minCost < Cost)
		{
			NodeSet *nn = new NodeSet(sel);
			nn->maxDiam = maxDiam;
			nn->maxDist = maxDist;
			nn->minCost = minCost;
			nn->bitmap = bitmap;
			nn->nodes = sel->nodes;
			nn->nodes.push_back(rtp);
			if(dupAllowed > 0)
				status = EnumerateMultiNode(nn, dupAllowed - 1, i+1, level, size-1, isLeaf);		//begin the recursion				
			status = EnumerateMultiNode(nn, dupAllowed, 0, level+1, size-1, isLeaf);
			delete nn;

			if(status == false)
				return status;
		}
	}
	return status;
}

bool Problem2Exact2::EnumerateOneNode(NodeSet *sel, int size, vector<RTreeNode *> *L, int idx, bool isLeaf)
{
	if(istimeout() || queueNodeSet.size() > 2000000)
	{
		return false;
	}

	if(idx < 0 || size == 0 || sel->bitmap== keywordsBM)
	{
		if(!isLeaf)
		{
			if(sel->bitmap == keywordsBM)
			{
				NodeSet *nn = new NodeSet(sel);
				queueNodeSet.push(nn);
			}
		}
		else
		{
			if(sel->bitmap == keywordsBM)
			{
				NodeSet *nn = optimal;
				if(Cost > sel->minCost)
				{
					delete nn;
					nn = new NodeSet(sel);
					Cost = nn->minCost;
				}
				if(nn != optimal)
					optimal = nn;
			}
		}
		if(idx < 0 || size == 0)
			return true;
	}

	bool status = true;
	
	for(int i=idx; i >= 0; i--)
	{
		RTreeNode *rtp = L->at(i);	

		double maxDist = rtp->minValue > sel->maxDist ? rtp->minValue :  sel->maxDist;
		double maxDiam = 0;
		vector<RTreeNode *>::iterator si;
		for(si = sel->nodes.begin(); si != sel->nodes.end(); ++si)
		{
			RTreeNode *rtp2 = *si;
			double diam;
			if(isLeaf)
			{
				double dx = rtp->pr->m_pLow[0] - rtp2->pr->m_pLow[0];
				double dy = rtp->pr->m_pLow[1] - rtp2->pr->m_pLow[1];
				diam = sqrt(dx *dx + dy * dy);
			}
			else
			{
				diam = ComputeMBRDist(rtp->pr, rtp2->pr);
			}			 
			if(diam > maxDiam)
				maxDiam = diam;
		}		
		maxDiam = maxDiam > sel->maxDiam ? maxDiam : sel->maxDiam;
		double minCost = alpha * maxDist + (1-alpha) * maxDiam;

		if(minCost < Cost)
		{
			NodeSet *nn = new NodeSet(sel);
			nn->maxDist = maxDist;
			nn->maxDiam = maxDiam;
			nn->minCost = minCost;
			nn->bitmap = rtp->bitmap | sel->bitmap;
			nn->nodes = sel->nodes;
			nn->nodes.push_back(rtp);
			status = EnumerateOneNode(nn, size-1, L, i-1, isLeaf);
			delete nn;
			if(status == false)
				return status;
		}		
	}
	return status;
}

bool Problem2Exact2::EnumerateOneNode(bool isLeaf)
{	
	vector<NodeSet *> *combination = new vector<NodeSet *>;

	vector<RTreeNode *> *sl = setLists[0]; 
	vector<RTreeNode *>::iterator ni;
	vector<NodeSet *> *L = new vector<NodeSet *>();
	
	for(ni = sl->begin(); ni != sl->end(); ++ni)
	{
		RTreeNode *rtp = *ni;
		NodeSet *nn = new NodeSet(rtp, alpha);
		L->push_back(nn);

		if(nn->bitmap == keywordsBM && Cost > nn->minCost)
		{
			combination->push_back(nn);
			nn->cite = 1;
		}		
	}
	//delete sl;
	
	set<long long> mutexpairs;			//two nodes that cannot combine, key: node1.id + node2.id
	set<long long>::iterator pairIter;
	map<long long, double> pairDist;

	int maxSize = keywords.size();
	int i;
	for(i=2;i<=maxSize;i++)
	{
		vector<NodeSet *> *Li = new vector<NodeSet *>;	//Li is a list, store all possible nodesets with size i

		KEYTYPE levelBM = 0;							//the keywords covered by this level

		for(unsigned int m=0;m<L->size();m++)
		{
			NodeSet * p1 = (*L)[m];			

			for(unsigned int n=m+1;n<L->size();n++)
			{
				if(istimeout())
				{
					cout<<"timeout-One"<<endl;

					vector<NodeSet *>::iterator vi;
					for(vi = L->begin(); vi != L->end(); ++vi)
					{
						NodeSet *nn = *vi;
						if(nn->cite == 0)
						delete nn;
					}
					delete L;

					int count = 0;
					for(vi = combination->begin(); vi != combination->end(); ++vi)
					{
						NodeSet *nn = *vi;
						delete nn;
					}
					delete combination;
					return false;
				}

				NodeSet * p2 = (*L)[n];

				KEYTYPE ubm = p1->bitmap | p2->bitmap;
				int num = MyTool::getNumOf1(ubm);
				if( num < i)		//E.g., three nodes ABC, but only covers 2 words, thus can be ignored
					continue;

				bool sharePrefix = true;		//check if two nodesets with size n share the same (n-1)nodes
				for(int k=0;k<i-2;k++)
				{
					if( (p1->nodes)[k] != (p2->nodes)[k])
					{
						sharePrefix = false;
						break;
					}
				}
				if(!sharePrefix)		//nodesets are ordered alphabetically, thus should be break
					break;//continue;

				RTreeNode *rtp1 = (p1->nodes)[i-2];
				RTreeNode *rtp2 = (p2->nodes)[i-2];

				if( i==2 )		//find all mutexpairs
				{
					long long key =  ( (long long)rtp1->identifier << 32 ) + rtp2->identifier;

					double diam;
					if(!isLeaf)
						diam = ComputeMBRDist(rtp1->pr, rtp2->pr);
					else
					{
						double dx = rtp1->pr->m_pLow[0] - rtp2->pr->m_pLow[0];
						double dy = rtp1->pr->m_pLow[1] - rtp2->pr->m_pLow[1];
						diam = sqrt(dx *dx + dy * dy);
					}
					double maxDist = p1->maxDist > p2->maxDist ? p1->maxDist : p2->maxDist;
					pairDist[key] = diam;

					double minCost = (1-alpha) * diam + alpha * maxDist;
					if(minCost < Cost)
					{
						NodeSet *p = new NodeSet();
						p->nodes.insert(p->nodes.begin(), p1->nodes.begin(), p1->nodes.end());
						p->nodes.push_back( rtp2 );
						p->bitmap = ubm;
						p->maxDiam = diam;
						p->maxDist = maxDist;
						p->minCost = minCost;
						Li->push_back(p);

						if(p->bitmap == keywordsBM)
						{
							combination->push_back(p);
							p->cite = 1;
						}
						//levelBM = levelBM | ubm;
					}
					else		//the two pairs cannot be combined
					{	
						mutexpairs.insert(key);
					}
				}

				else		//E.g., given ABC and ABD, if C and D are mutexpair, then the two nodesets cannot be combined							
							//However, even though, ABCD may still not be a candidate nodeset
							//because the maxDiam could be the distance between C and D, which may be larger
				{
					long long key =  ( (long long)rtp1->identifier << 32 ) + rtp2->identifier;
					if( (pairIter = mutexpairs.find(key)) != mutexpairs.end() )
						continue;

					double maxDist = p1->maxDist > p2->maxDist ? p1->maxDist : p2->maxDist;
					double maxDiam = p1->maxDiam > p2->maxDiam ? p1->maxDiam : p2->maxDiam;
					double diam = pairDist[key];
					maxDiam = diam > maxDiam ? diam : maxDiam;
					double minCost = (1-alpha) * maxDiam + alpha * maxDist;
					if(minCost < Cost)
					{
						NodeSet *p = new NodeSet();
						p->nodes.insert(p->nodes.begin(), p1->nodes.begin(), p1->nodes.end());
						p->nodes.push_back( rtp2 );
						p->bitmap = ubm;
						p->maxDiam = maxDiam;
						p->maxDist = maxDist;
						p->minCost = minCost;
						Li->push_back(p);

						if(p->bitmap == keywordsBM)
						{
							combination->push_back(p);
							p->cite = 1;
						}
						//levelBM = levelBM | ubm;
					}
				}					
			}
		}

		vector<NodeSet *>::iterator li;
		for(li = L->begin(); li != L->end(); ++li)
		{
			NodeSet *p = *li;
			if(p->cite == 0)
				delete p;
		}
		delete L; L = Li;
		//ע��delete L��ʱ���Ѿ���setLists������Ŀռ��ͷ���, �������е�nodeset, ���ں��������ͷ�combinationʱdelete
	}
	vector<NodeSet *>::iterator li;
	for(li = L->begin(); li != L->end(); ++li)
	{
		NodeSet *p = *li;
		if(p->cite == 0)
			delete p;
	}
	delete L;

	if(isLeaf)
	{
		vector<NodeSet *>::iterator vi;
		for(vi = combination->begin(); vi != combination->end(); ++vi)
		{
			NodeSet *nn = *vi;
			if(nn->bitmap == keywordsBM && Cost > nn->minCost)
			{
				Cost = nn->minCost;
				delete optimal;
				optimal = new NodeSet(nn);
				//cout<<2<<endl;getchar();
			}
			delete nn;
		}
	}
	else
	{
		vector<NodeSet *>::iterator vi;
		for(vi = combination->begin(); vi != combination->end(); ++vi)
		{
			NodeSet *nn = *vi;
			if(nn->bitmap == keywordsBM && Cost > nn->minCost)
			{
				queueNodeSet.push(nn);				
			}
			else
				delete nn;
		}
	}
	delete combination;
	return true;
}


void Problem2Exact2::getNextEntry(const IEntry& entry, id_type& nextEntry, bool& hasNext)
{
	const INode* n = dynamic_cast<const INode*>(&entry);

	if (n != 0)
	{			
		int pid = n->getIdentifier();

#ifdef _DEBUG
		++time;
		cout<<pid<<":"<<time<<endl;		
#endif		
		//if(pid == 135 && ns->nodes.empty() && setLists.empty())
		//if(pid == 69 && time == 1147)
		//	cout<<pid;
		
		string btFile = btreeFolder + MyTool::IntToString(pid);
		char *btfname = new char[btFile.size()+1];
		memcpy(btfname, btFile.c_str(), btFile.size());		
		btfname[btFile.size()] = '\0';
		BTree *bt = new BTree(btfname, 0);				
		
		map<int, int> objectTexts;					//the text description of an object
		set<int> indexID;						//the id of child nodes which contains query keywords				
		map<int, int>::iterator iterMap;
		int wsize = keywords.size();			
		for(unsigned int k=0;k<wsize;k++)
		{
			int wordID = keywords[k];
			VECTYPE *data = new VECTYPE[DIMENSION];
			bool flag = bt->search(wordID, &data);
			if(flag)
			{					
				for(int i=0;i<DIMENSION;i++)
				{
					if(data[i] > 0)							
					{
						unsigned char mask = 1;
						for(int j=0;j<8;j++)
						{
							if((data[i] & mask) > 0)
							{
								int index = i*8+j;
								indexID.insert(index);								

								iterMap = objectTexts.find(index);
								if(iterMap == objectTexts.end())
								{
									objectTexts[index] = 1<<k;	
								}
								else
								{
									int key = objectTexts[index];
									objectTexts[index] = key | 1 <<k;
								}
							}
							mask = mask << 1;
						}
					}
				}
			}
			delete data;
		}
		delete bt;
		delete btfname;

		vector<RTreeNode *> *candidateNodes = new vector<RTreeNode *>();
		set<int>::iterator si = indexID.begin();
		for(;si != indexID.end(); ++si)	
		{
			uint32_t cChild = *si;
			int cid = n->getChildIdentifier(cChild);
			
			IShape *out;
			n->getChildShape(cChild, &out);
			Region* pr = dynamic_cast<Region *>(out);				
			
			RTreeNode *rtp;
			map<int, RTreeNode *>::iterator oi = nodesBuffer.find(cid);
			if( oi != nodesBuffer.end())	//this node is in the buffer, read it directly
			{
				rtp = oi->second;
				if(alpha * rtp->minValue > Cost)
					continue;
				candidateNodes->push_back(rtp);
			}
			else
			{
				double dist;
				if(n->isIndex())
				{
					double coor[2];
					coor[0] = Q->x; coor[1] = Q->y;
					Point pt(coor, 2);
					dist = ComputeMinPossible(pr, &pt);
				}
				else
				{
					double dx = Q->x - pr->m_pLow[0];
					double dy = Q->y - pr->m_pLow[1];
					dist = sqrt ( dx * dx + dy * dy ); 
				}

				if( alpha * dist > Cost)		//the node cannot contribute to final results
					continue;					
				
				rtp = new RTreeNode();
				rtp->identifier = n->getChildIdentifier(cChild);
				rtp->minValue = dist;
				rtp->bitmap = objectTexts[cChild];
				rtp->pr = pr;

				candidateNodes->push_back(rtp);
				nodesBuffer[rtp->identifier] = rtp;				
			}
			int mask = 1;
			for(unsigned int i=0; i<keywords.size(); i++, mask = mask<<1)
			{
				if( (rtp->bitmap & mask) > 0)
					inverted[i].push_back(rtp);
			}
		}

		setLists.push_back(candidateNodes);
		
		if( !(ns->nodes.empty()) && candidateNodes->size() > 0)		//we are only retrieving a node in ns, we keep reading, until all nodes in ns are read
		{
			id_type page = ns->nodes.back()->identifier;
			ns->nodes.pop_back();
			//RTreeNode *rtp = *(ns->nodes.begin());
			//id_type page = rtp->identifier;
			//ns->nodes.erase(rtp);
			hasNext = true;
			nextEntry = page;
		}
		else
		{
			bool status = true;
			if(candidateNodes->size() > 0)
			{
				NodeSet *nn = new NodeSet();
				bool isLeaf = false;
				if(n->isLeaf())
					isLeaf = true;
				if(setLists.size() == 1)
				{
					cout<<"One"<<":"<<queueNodeSet.size()<<endl;
					//status = EnumerateOneNode(isLeaf);
					vector<RTreeNode *> *p = setLists[0];
					status = EnumerateOneNode(nn, keywords.size(), p, p->size()-1, isLeaf); //delete p;
				}
				else
				{
					cout<<"Mul"<<":"<<queueNodeSet.size()<<endl;
					//status = EnumerateMultiNode(isLeaf); 
					int moreAllowed = keywords.size() - setLists.size();
					if(moreAllowed <= 0)	moreAllowed = 0;
					status = EnumerateMultiNode(nn, moreAllowed, 0, 0, keywords.size(), isLeaf);
				}
				delete nn;
			}

			//vector< vector<RTreeNode *> * >::iterator sli;
			//for(sli = setLists.begin(); sli != setLists.end(); ++sli)
			for(int i=0;i<setLists.size(); i++)
			{
				delete setLists[i];
			}

			setLists.clear();
			for(unsigned int i=0;i<keywords.size();i++)
				inverted[i].clear();

			if(!status)
			{
				Cost = -1;
				hasNext = false;				
				cout<<"timeout"<<endl;
				return;
			}

			if(!queueNodeSet.empty())		//we still have nodeset in queue, we need to read nodes for the next one
			{	
				delete ns;
				ns = queueNodeSet.top();
				queueNodeSet.pop();

				if(ns->minCost > Cost)
				{	
					hasNext = false;
				}
				else
				{
					id_type page = ns->nodes.back()->identifier;
					ns->nodes.pop_back();
					//RTreeNode *rp = *(ns->nodes.begin());
					//id_type page = rp->identifier;
					//ns->nodes.erase(rp);
					nextEntry = page;
					hasNext = true;					
				}
			}
			else
			{	
				hasNext = false;
			}
		}
	}

	else
		hasNext = false;
}
