1. This dataset is used in the paper, namely, the Hotel dataset.There are two files:

a) The "loc" file stores the coordinates of locations. Each line is in format of "id, latitude, longitude".

b) The "doc" file stores the terms associated with each location. Each line is in format of "id,  a set of terms".

Notice that due to some reason "id" is not used. Instead, the real ID of each location is its  position in the file (starting from zero).

2. The code is compiled in VS2010. It needs the R-tree library, which can be downloaded from http://libspatialindex.github.com/. In the package, both debug and release libraries are already provided. You can also download the R-tree code and compile it by yourself.

Please configure your own project properly (include path, lib path, and dll path).

a). The variable "numOfEntry" is the maximum number of child nodes in the IR-tree. It must be consistent with the macro NODENUM in "data.h".

b). Please refer to the member function BuildIBRTree() of the class IBRTree to see how to build an IR-tree. The details are shown in that function. In order to make it more clear, the building process is divided into several steps. The intermediate files are also kept.

c). After building the IR-tree, you can search using the class SearchIBRTree. The code in the main function shows how to do this.
